"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Loader2, Plus, RefreshCw, CornerDownLeft, Brain, ShieldCheck, ShieldX, Bot as BotIcon, Cpu, Layers, ExternalLink, MessagesSquare } from "lucide-react";

// OpenMausBot — the free, open-source Grok Bot alternative, wired into the OS.
// Every contact in the roster is a real agent running on a CLI you already pay
// for (claude / codex / grok). This tab talks to the SAME local harness the
// OpenMausBot app uses (127.0.0.1:8799), so the roster, the threads and the
// running turns are shared — start a job here, watch it finish in the app.
//
// The OS adds one thing the app can't: shared memory. Flip Vault memory on and
// the bot reads and writes the same Obsidian brain as Hermes and Claude.

const MB = "#1084fe";   // OpenMausBot blue
const OK = "#34E5B0";
const WARN = "#e8728a";
const GOLD = "#d4a574";

interface Msg { id: string; role: "bot" | "user"; kind: string; text?: string; tool?: { name: string; ok?: boolean }; card?: { title?: string; subtitle?: string; options?: string[]; answered?: string | boolean; requestId?: string }; at: number }
// older bots on disk carry `modelId` instead of `model` — read both
interface Bot { id: string; threadId: string; name: string; description?: string; color?: string; busy?: boolean; modelSelection: { instanceId: string; model?: string; modelId?: string }; messages?: Msg[] }
const modelOf = (b: Bot) => b.modelSelection?.model ?? b.modelSelection?.modelId ?? "default";
interface Model { id: string; label: string }
interface Instance { instanceId: string; displayName: string; snapshot?: { state?: string; version?: string; authenticated?: boolean }; models?: { default: string; options: Model[] } }
interface Status { connected: boolean; harness: string; error?: string; instances: Instance[]; bots: Bot[]; vault: string | null; memoryFile: string }

const COLORS: Record<string, string> = { orange: "#f0a868", red: "#e8728a", blue: MB, green: OK, purple: "#c084fc", yellow: "#fde047", pink: "#f472b6" };

interface WFile { rel: string; bytes: number; mtime: number; ext: string; text: string | null }
interface Project { project: string; mtime: number; files: WFile[]; html: string[] }

export default function OpenMausBotView() {
  const [st, setSt] = useState<Status | null>(null);
  const [sel, setSel] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [memory, setMemory] = useState(true);
  const [sending, setSending] = useState(false);
  const [tab, setTab] = useState<"team" | "workspace">("team");
  const [projects, setProjects] = useState<Project[]>([]);
  const [openFile, setOpenFile] = useState<{ project: string; file: WFile } | null>(null);
  const threadRef = useRef<HTMLDivElement>(null);

  const loadWork = useCallback(async () => {
    try { const r = await fetch("/api/openmausbot/workspace", { cache: "no-store" }); const j = await r.json(); setProjects(j.projects ?? []); } catch { /* offline */ }
  }, []);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/openmausbot", { cache: "no-store" });
      const j: Status = await r.json();
      setSt(j);
      setSel((cur) => cur && j.bots.some((b) => b.id === cur) ? cur : j.bots[0]?.id ?? null);
    } catch { /* offline */ }
  }, []);

  useEffect(() => { load(); loadWork(); }, [load, loadWork]);
  // poll while anything is thinking, so a turn streams in without a refresh
  useEffect(() => {
    const busy = st?.bots.some((b) => b.busy);
    const ms = busy || sending ? 1500 : 6000;
    const t = setInterval(() => { load(); if (busy) loadWork(); }, ms);
    return () => clearInterval(t);
  }, [st, sending, load, loadWork]);
  useEffect(() => { if (threadRef.current) threadRef.current.scrollTop = threadRef.current.scrollHeight; }, [st, sel]);

  const bot = st?.bots.find((b) => b.id === sel) ?? null;
  const models = st?.instances.flatMap((i) => (i.models?.options ?? []).map((m) => ({ ...m, instanceId: i.instanceId, provider: i.displayName, up: i.snapshot?.state === "available" }))) ?? [];

  async function post(payload: Record<string, unknown>) {
    const r = await fetch("/api/openmausbot", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    return r.json().catch(() => ({}));
  }

  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || !sel || sending) return;
    setInput(""); setSending(true);
    await post({ action: "send", botId: sel, text, memory });
    await load();
    setSending(false);
  }, [input, sel, sending, memory, load]);

  async function newBot() {
    const name = prompt("Name this bot (e.g. SEO Researcher, Inbox Agent)")?.trim();
    if (!name) return;
    const j = await post({ action: "create", name });
    await load();
    if (j?.bot?.id) setSel(j.bot.id);
  }

  async function setModel(instanceId: string, model: string) {
    if (!sel) return;
    await post({ action: "model", botId: sel, modelSelection: { instanceId, model } });
    load();
  }

  async function answer(requestId: string, behavior: "allow" | "deny") {
    if (!sel) return;
    await post({ action: "respond", botId: sel, requestId, behavior });
    load();
  }

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* header */}
      <div className="flex items-center gap-3 mb-3 shrink-0 flex-wrap">
        <div className="w-8 h-8 rounded-lg grid place-items-center font-bold text-[#04121f]" style={{ background: `linear-gradient(135deg,${MB},${OK})` }}>◍</div>
        <div className="min-w-0">
          <div className="text-[15px] font-semibold text-[var(--cream)] leading-none flex items-center gap-2 flex-wrap">
            OpenMausBot
            <span className="inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded-full" style={{ background: `${MB}1e`, color: MB, border: `1px solid ${MB}40` }}>
              {st == null ? <Loader2 size={9} className="animate-spin" /> : <span className="w-1.5 h-1.5 rounded-full" style={{ background: st.connected ? OK : WARN }} />}
              {st == null ? "checking" : st.connected ? "harness live · 127.0.0.1:8799" : "harness offline"}
            </span>
            {st?.instances.filter((i) => i.snapshot?.state === "available").map((i) => (
              <span key={i.instanceId} className="text-[9.5px] mono px-1.5 py-0.5 rounded-full border" style={{ borderColor: "var(--line-soft)", color: "var(--cream-dim)" }}>{i.displayName} ✓</span>
            ))}
          </div>
          <div className="text-[10.5px] text-[var(--cream-mute)] mt-1">A team of agents in a chat app · one model per bot · runs on the CLIs you already pay for · same roster as the OpenMausBot app</div>
        </div>
        <div className="ml-auto flex gap-1.5 items-center">
          {([{ k: "team", label: "Team", icon: <MessagesSquare size={11} />, n: st?.bots.length ?? 0 },
             { k: "workspace", label: "Workspace", icon: <Layers size={11} />, n: projects.length }] as const).map((t) => (
            <button key={t.k} onClick={() => { setTab(t.k as "team" | "workspace"); if (t.k === "workspace") loadWork(); }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-medium border transition"
              style={{ borderColor: tab === t.k ? MB : "var(--line-soft)", background: tab === t.k ? `${MB}1e` : "transparent", color: tab === t.k ? MB : "var(--cream-dim)" }}>
              {t.icon}{t.label}{t.n ? ` · ${t.n}` : ""}
            </button>
          ))}
          <button onClick={newBot} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] font-medium border" style={{ borderColor: `${MB}55`, color: MB, background: `${MB}12` }}><Plus size={12} /> New bot</button>
          <button onClick={() => { load(); loadWork(); }} className="p-2 rounded-lg border border-[var(--line-soft)] text-[var(--cream-mute)] hover:text-[var(--cream)]"><RefreshCw size={12} /></button>
        </div>
      </div>

      {st && !st.connected && (
        <div className="rounded-xl border px-4 py-3 mb-3 text-[12px]" style={{ borderColor: `${WARN}55`, background: `${WARN}0e`, color: "var(--cream-soft)" }}>
          {st.error} <span className="text-[var(--cream-mute)]">The roster below is empty until it is.</span>
        </div>
      )}

      {tab === "workspace" && (
        <div className="panel p-0 flex flex-col min-h-0 flex-1 overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-2.5 border-b border-[var(--line-soft)] shrink-0">
            <Layers size={14} style={{ color: MB }} />
            <span className="text-[12.5px] text-[var(--cream)] font-medium">What the team built</span>
            <span className="text-[10.5px] text-[var(--cream-mute)]">{projects.length} project{projects.length === 1 ? "" : "s"} · ~/.agentic-os/openmausbot-workspace</span>
            {openFile && <button onClick={() => setOpenFile(null)} className="ml-auto text-[11px]" style={{ color: MB }}>← all work</button>}
          </div>
          <div className="flex-1 min-h-0 overflow-y-auto scroll p-3">
            {openFile ? (
              <div>
                <div className="text-[11px] mono mb-2" style={{ color: "var(--cream-dim)" }}>{openFile.project}/{openFile.file.rel}</div>
                <pre className="text-[12px] whitespace-pre-wrap leading-relaxed p-4 rounded-xl border" style={{ borderColor: "var(--line-soft)", background: "var(--bg-card)", color: "var(--cream-soft)" }}>{openFile.file.text}</pre>
              </div>
            ) : projects.length === 0 ? (
              <div className="h-full grid place-items-center text-center text-[11.5px] text-[var(--cream-mute)] max-w-[360px] mx-auto">
                Nothing built yet. Give a bot a job in Team — anything it writes lands here, and HTML previews live.
              </div>
            ) : (
              <div className="space-y-4">
                {projects.map((pr) => (
                  <div key={pr.project}>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="w-1.5 h-1.5 rounded-full" style={{ background: MB }} />
                      <span className="text-[12.5px] font-medium mono" style={{ color: "var(--cream)" }}>{pr.project}</span>
                      <span className="text-[10px]" style={{ color: "var(--cream-mute)" }}>{pr.files.length} file{pr.files.length === 1 ? "" : "s"}</span>
                    </div>
                    <div className={`grid grid-cols-1 gap-3 ${pr.files.length > 1 ? "md:grid-cols-2" : ""}`}>
                      {pr.files.map((f) => {
                        const url = `/api/openmausbot/preview/${pr.project}/${encodeURIComponent(f.rel)}`;
                        return (
                          <div key={f.rel} className="rounded-xl border overflow-hidden bg-[var(--bg-card)]" style={{ borderColor: "var(--line-soft)" }}>
                            {f.ext === ".html"
                              ? <iframe src={url} title={f.rel} loading="lazy" sandbox="allow-scripts allow-same-origin" className="w-full border-0 bg-black" style={{ aspectRatio: "16/10" }} />
                              : <pre onClick={() => setOpenFile({ project: pr.project, file: f })} className="w-full overflow-hidden text-[11px] leading-[1.75] px-4 py-3 cursor-pointer mono whitespace-pre-wrap" style={{ maxHeight: 300, color: "var(--cream-soft)", margin: 0, maskImage: "linear-gradient(#000 72%,transparent)", WebkitMaskImage: "linear-gradient(#000 72%,transparent)" }}>{(f.text ?? "").slice(0, 1100)}</pre>}
                            <div className="px-3 py-2 flex items-center gap-2 border-t" style={{ borderColor: "var(--line-soft)" }}>
                              <span className="text-[11.5px] mono truncate" style={{ color: "var(--cream)" }}>{f.rel}</span>
                              <a href={url} target="_blank" rel="noopener" className="ml-auto text-[10px] inline-flex items-center gap-1 shrink-0" style={{ color: MB }}><ExternalLink size={9} /> open</a>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      <div className="flex gap-3 flex-1 min-h-0" style={{ display: tab === "team" ? undefined : "none" }}>
        {/* ── roster ── */}
        <div className="panel p-0 w-[230px] shrink-0 flex flex-col min-h-0 overflow-hidden">
          <div className="px-3 py-2 border-b border-[var(--line-soft)] text-[10px] uppercase tracking-widest text-[var(--cream-mute)] shrink-0">Contacts · {st?.bots.length ?? 0}</div>
          <div className="flex-1 min-h-0 overflow-y-auto scroll p-2 space-y-1">
            {(st?.bots ?? []).map((b) => {
              const c = COLORS[b.color ?? "blue"] ?? MB;
              return (
                <button key={b.id} onClick={() => setSel(b.id)} className="w-full text-left rounded-lg border px-2.5 py-2 transition"
                  style={{ borderColor: sel === b.id ? `${c}66` : "transparent", background: sel === b.id ? `${c}12` : "transparent" }}>
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full grid place-items-center shrink-0 text-[11px]" style={{ background: `${c}22`, color: c }}><BotIcon size={12} /></span>
                    <span className="text-[12px] font-medium truncate" style={{ color: "var(--cream)" }}>{b.name || "New Bot"}</span>
                    {b.busy && <Loader2 size={10} className="animate-spin ml-auto shrink-0" style={{ color: c }} />}
                  </div>
                  <div className="text-[9.5px] mono mt-1 truncate" style={{ color: "var(--cream-mute)" }}>{modelOf(b)}</div>
                </button>
              );
            })}
            {st?.bots.length === 0 && <div className="text-[11px] text-[var(--cream-mute)] p-3 text-center">No bots yet. Hit <b>New bot</b> — it appears here and in the OpenMausBot app.</div>}
          </div>
        </div>

        {/* ── thread ── */}
        <div className="panel p-0 flex-1 flex flex-col min-h-0 overflow-hidden">
          {!bot ? (
            <div className="flex-1 grid place-items-center text-[11.5px] text-[var(--cream-mute)] text-center px-6">
              Pick a contact on the left, or make a new one.<br />Every contact is a real agent with its own model, memory and apps.
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 px-4 py-2.5 border-b border-[var(--line-soft)] shrink-0 flex-wrap">
                <span className="text-[12.5px] font-medium" style={{ color: "var(--cream)" }}>{bot.name || "New Bot"}</span>
                <Cpu size={11} style={{ color: "var(--cream-mute)" }} />
                <select value={`${bot.modelSelection.instanceId}::${modelOf(bot)}`}
                  onChange={(e) => { const [i, m] = e.target.value.split("::"); setModel(i, m); }}
                  className="bg-transparent text-[11px] mono border rounded-md px-1.5 py-0.5 focus:outline-none"
                  style={{ borderColor: "var(--line-soft)", color: "var(--cream-dim)" }}>
                  {models.map((m) => (
                    <option key={`${m.instanceId}::${m.id}`} value={`${m.instanceId}::${m.id}`} disabled={!m.up} style={{ background: "#150f24" }}>
                      {m.provider} · {m.label}{m.up ? "" : " (offline)"}
                    </option>
                  ))}
                </select>
                {bot.busy && <span className="inline-flex items-center gap-1 text-[10px]" style={{ color: MB }}><Loader2 size={10} className="animate-spin" /> working</span>}
                <span className="ml-auto text-[9.5px] mono" style={{ color: "var(--cream-mute)" }}>~/.openmausbot · {bot.threadId.slice(0, 8)}</span>
              </div>

              <div ref={threadRef} className="flex-1 min-h-0 overflow-y-auto scroll px-4 py-3 space-y-2">
                {(bot.messages ?? []).map((m) => {
                  if (m.kind === "activity") return (
                    <div key={m.id} className="text-[10.5px] mono flex items-center gap-1.5" style={{ color: "var(--cream-mute)" }}>
                      <span style={{ color: m.tool?.ok === false ? WARN : OK }}>⎿</span> {m.tool?.name ?? "tool"}
                    </div>
                  );
                  if (m.kind === "options" && m.card) {
                    const live = Boolean(m.card.requestId) && !m.card.answered;
                    const opts = m.card.options ?? [];
                    return (
                      <div key={m.id} className="rounded-xl border px-3.5 py-3 max-w-[560px]" style={{ borderColor: `${GOLD}55`, background: `${GOLD}0e` }}>
                        <div className="text-[9.5px] uppercase tracking-widest mb-1.5" style={{ color: GOLD }}>{live ? "It's asking you" : "Card"}</div>
                        <div className="text-[12.5px]" style={{ color: "var(--cream)" }}>{m.card.title}</div>
                        {m.card.subtitle && <div className="text-[11px] mt-1 mb-2" style={{ color: "var(--cream-mute)" }}>{m.card.subtitle}</div>}
                        <div className="flex gap-2 flex-wrap mt-2">
                          {opts.map((o) => {
                            const yes = /^allow/i.test(o);
                            const no = /^deny|^reject/i.test(o);
                            return (
                              <button key={o} disabled={!live} onClick={() => answer(m.card!.requestId!, yes ? "allow" : "deny")}
                                className="inline-flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-lg border disabled:opacity-45"
                                style={{ borderColor: yes ? `${OK}66` : no ? `${WARN}66` : "var(--line-soft)", color: yes ? OK : no ? WARN : "var(--cream-dim)" }}>
                                {yes && <ShieldCheck size={11} />}{no && <ShieldX size={11} />}{o}
                              </button>
                            );
                          })}
                        </div>
                        {m.card.answered && <div className="text-[10px] mt-2" style={{ color: "var(--cream-mute)" }}>answered · {String(m.card.answered)}</div>}
                      </div>
                    );
                  }
                  const mine = m.role === "user";
                  const shown = mine ? (m.text ?? "").replace(/^\[Agent OS shared memory[\s\S]*?--- the actual job ---\s*/, "") : (m.text ?? "");
                  const tagged = mine && (m.text ?? "").startsWith("[Agent OS shared memory");
                  return (
                    <div key={m.id} className={`max-w-[620px] ${mine ? "ml-auto" : ""}`}>
                      {tagged && <div className="text-[9px] mono mb-1 text-right" style={{ color: "#22d3ee" }}>+ vault memory</div>}
                      <div className="rounded-xl border px-3.5 py-2.5 text-[12.5px] whitespace-pre-wrap leading-relaxed"
                        style={{ borderColor: mine ? `${MB}44` : "var(--line-soft)", background: mine ? `${MB}12` : "var(--bg-card)", color: "var(--cream-soft)" }}>
                        {shown}
                      </div>
                    </div>
                  );
                })}
                {(bot.messages ?? []).length === 0 && <div className="text-[11.5px] text-[var(--cream-mute)] text-center pt-10">Say what you want done. It runs on your own CLI, on your Mac.</div>}
              </div>

              <div className="border-t border-[var(--line-soft)] px-3.5 py-2 shrink-0 flex items-center gap-2 flex-wrap">
                <button onClick={() => setMemory((v) => !v)} className="inline-flex items-center gap-1.5 mono text-[10.5px] px-2 py-1 rounded-full border transition"
                  style={{ borderColor: memory ? "#22d3ee66" : "var(--line-soft)", color: memory ? "#22d3ee" : "var(--cream-mute)", background: memory ? "#22d3ee12" : "transparent" }}>
                  <Brain size={11} /> Vault memory {memory ? "on" : "off"}
                </button>
                <span className="text-[10px]" style={{ color: "var(--cream-mute)" }}>
                  {memory ? `reads the vault first, logs what it did to ${st?.memoryFile}` : "this bot works with no shared context"}
                </span>
              </div>

              <div className="border-t border-[var(--line-soft)] px-3.5 py-2.5 shrink-0 flex items-center gap-2">
                <span className="mono text-[13px]" style={{ color: sending ? "var(--cream-mute)" : MB }}>❯</span>
                <input value={input} onChange={(e) => setInput(e.target.value)} disabled={sending || !st?.connected}
                  onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
                  placeholder={st?.connected ? `message ${bot.name || "this bot"}…` : "harness offline"}
                  className="flex-1 bg-transparent text-[13px] focus:outline-none disabled:opacity-60" style={{ color: "var(--cream)" }} />
                <button onClick={send} disabled={!input.trim() || sending || !st?.connected} className="inline-flex items-center gap-1 mono text-[11px] px-2 py-1 rounded border disabled:opacity-30" style={{ borderColor: `${MB}55`, color: MB }}>
                  {sending ? <Loader2 size={11} className="animate-spin" /> : <CornerDownLeft size={11} />} send
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
