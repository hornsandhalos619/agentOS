"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Bot as BotIcon, Plus, Send, Loader2, Clock, Inbox, Sparkles, RefreshCw,
  Play, Pause, Trash2, X as XIcon, AtSign, ScrollText, Search, Zap,
} from "lucide-react";

// Bot Mode — a roster of named bots over Hermes profiles.
// Everything here drives the real primitives: `hermes profile create`,
// `hermes cron create --name "[bot:x] ..."`, and the bot-to-bot handoff
// `hermes -p <bot> chat --in ~ -c "Agent Inbox" -q "[Message from agent 'x'] ..."`.

const ACCENT = "#60a5fa";

interface Bot {
  name: string; title: string; model: string; provider: string; soul: string;
  sessions: number; lastActive: number; active: boolean;
  hasInbox: boolean; inboxCount: number; lastMessage: string;
  routines: number; skills: number;
  avatar: { shape: string; color: string };
}
interface Routine {
  id: string; bot: string; title: string; schedule: string; enabled: boolean;
  nextRun: string | null; lastRun: string | null; lastStatus: string | null;
  prompt: string; ownerProfile: string;
}
interface InboxMessage { role: "user" | "assistant"; from: string | null; text: string; at: number }
interface Handoff {
  id: string; from: string; to: string; message: string;
  status: "running" | "done" | "failed"; startedAt: number; finishedAt?: number;
  reply: string; error?: string;
}

function fmtAgo(ms?: number): string {
  if (!ms) return "never";
  const d = Date.now() - ms;
  if (d < 60_000) return "just now";
  if (d < 3_600_000) return `${Math.floor(d / 60_000)}m ago`;
  if (d < 86_400_000) return `${Math.floor(d / 3_600_000)}h ago`;
  return `${Math.floor(d / 86_400_000)}d ago`;
}

/** The bot's face: one of 7 geometric shapes, its own colour, blinking eyes
 *  that scan side to side while the bot is working. */
function Avatar({ shape, color, size = 34, busy = false }: { shape: string; color: string; size?: number; busy?: boolean }) {
  const body = (() => {
    switch (shape) {
      case "squircle": return <rect x="5" y="5" width="30" height="30" rx="10" fill={color} />;
      case "pill": return <rect x="6" y="9" width="28" height="22" rx="11" fill={color} />;
      case "triangle": return <path d="M20 5 L36 33 L4 33 Z" fill={color} />;
      case "hexagon": return <path d="M20 4 L34 12 L34 28 L20 36 L6 28 L6 12 Z" fill={color} />;
      case "cloud": return <path d="M12 28 a8 8 0 0 1 0-16 a10 10 0 0 1 19 -1 a7 7 0 0 1 -2 17 Z" fill={color} />;
      case "drop": return <path d="M20 4 C29 16 33 21 33 26 a13 13 0 0 1 -26 0 C7 21 11 16 20 4 Z" fill={color} />;
      default: return <circle cx="20" cy="20" r="15" fill={color} />;
    }
  })();
  const n = parseInt(color.slice(1), 16);
  const lum = 0.2126 * ((n >> 16) & 255) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255);
  const eye = lum < 110 ? "#f8fafc" : "#161219";
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" className="shrink-0">
      <g>{body}</g>
      <g fill={eye}>
        <ellipse cx="15.5" cy="19" rx="2" ry="2.4">
          {busy && <animate attributeName="cx" values="14.5;16.5;14.5" dur="1.6s" repeatCount="indefinite" />}
          <animate attributeName="ry" values="2.4;2.4;0.25;2.4;2.4" dur="4.2s" repeatCount="indefinite" />
        </ellipse>
        <ellipse cx="24.5" cy="19" rx="2" ry="2.4">
          {busy && <animate attributeName="cx" values="23.5;25.5;23.5" dur="1.6s" repeatCount="indefinite" />}
          <animate attributeName="ry" values="2.4;2.4;0.25;2.4;2.4" dur="4.2s" repeatCount="indefinite" />
        </ellipse>
      </g>
    </svg>
  );
}

export default function HermesBots() {
  const [bots, setBots] = useState<Bot[]>([]);
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [inbox, setInbox] = useState<InboxMessage[]>([]);
  const [soul, setSoul] = useState("");
  const [handoffs, setHandoffs] = useState<Handoff[]>([]);
  const [pane, setPane] = useState<"inbox" | "routines" | "soul">("inbox");
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [err, setErr] = useState<string | null>(null);

  const [msg, setMsg] = useState("");
  const [sending, setSending] = useState(false);
  const [live, setLive] = useState<Handoff | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [showNew, setShowNew] = useState(false);
  const [showRoutine, setShowRoutine] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const r = await (await fetch("/api/hermes/bots", { cache: "no-store" })).json();
      const list: Bot[] = r.bots ?? [];
      setBots(list);
      setRoutines(r.routines ?? []);
      // Land on a bot that has something to show, not an empty inbox.
      setSel((s) => s ?? (list.find((b) => b.inboxCount > 0)?.name ?? list[0]?.name ?? null));
    } catch (e) { setErr(String(e)); }
    finally { setLoading(false); }
  }, []);

  const loadBot = useCallback(async (name: string) => {
    try {
      const r = await (await fetch(`/api/hermes/bots?bot=${encodeURIComponent(name)}`, { cache: "no-store" })).json();
      setInbox(r.inbox ?? []);
      setSoul(r.soul ?? "");
      setHandoffs(r.handoffs ?? []);
    } catch { /* keep old */ }
  }, []);

  const feedRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => { if (sel) loadBot(sel); }, [sel, loadBot]);
  // Keep the newest message in view — including a handoff reply landing live.
  useEffect(() => {
    const el = feedRef.current;
    if (el && pane === "inbox") el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [inbox, live, pane]);
  useEffect(() => () => { if (pollRef.current) clearInterval(pollRef.current); }, []);

  const selected = bots.find((b) => b.name === sel) ?? null;
  const selRoutines = useMemo(() => routines.filter((r) => r.bot === sel), [routines, sel]);
  const shown = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return bots;
    return bots.filter((b) => b.name.includes(t) || b.title.toLowerCase().includes(t));
  }, [bots, q]);

  // @mention: "@researcher find X" routes the message to that bot instead.
  const mention = /^@([a-z0-9][a-z0-9_-]*)\s+([\s\S]+)$/i.exec(msg.trim());
  const target = mention && bots.some((b) => b.name === mention[1].toLowerCase()) ? mention[1].toLowerCase() : sel;

  async function send() {
    if (!target || !msg.trim() || sending) return;
    setSending(true); setErr(null);
    const text = mention && target === mention[1].toLowerCase() ? mention[2] : msg;
    try {
      const r = await (await fetch("/api/hermes/bots", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "send", to: target, from: "you", message: text }),
      })).json();
      if (r.error) { setErr(r.error); setSending(false); return; }
      setMsg("");
      setLive(r.handoff);
      if (pollRef.current) clearInterval(pollRef.current);
      pollRef.current = setInterval(async () => {
        try {
          const s = await (await fetch(`/api/hermes/bots?handoff=${r.handoff.id}`, { cache: "no-store" })).json();
          if (s.handoff) {
            setLive(s.handoff);
            if (s.handoff.status !== "running") {
              if (pollRef.current) clearInterval(pollRef.current);
              setSending(false);
              // Refresh the chat you're standing in — the handoff reply stays
              // pinned below it, the way a mention reports back in place.
              if (sel) loadBot(sel);
              refresh();
            }
          }
        } catch { /* keep polling */ }
      }, 2500);
    } catch (e) { setErr(String(e)); setSending(false); }
  }

  async function routineAction(id: string, action: "routine-toggle" | "routine-delete", enable?: boolean) {
    await fetch("/api/hermes/bots", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, id, enable }),
    });
    refresh();
  }

  return (
    <div className="flex flex-col min-h-0">
      {/* header */}
      <div className="flex items-center justify-between gap-3 mb-3 flex-wrap">
        <div className="flex items-center gap-2.5">
          <BotIcon size={16} style={{ color: ACCENT }} />
          <div>
            <div className="text-sm font-medium" style={{ color: ACCENT }}>Bot Mode</div>
            <div className="text-[11px] text-[var(--fg-dim)]">
              {bots.length} bots · {routines.length} routines · every bot is a real Hermes profile
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => { setShowNew(true); }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[12px] font-medium"
            style={{ background: ACCENT, color: "#0b1020" }}>
            <Plus size={13} /> New bot
          </button>
          <button onClick={refresh}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[12px] transition hover:bg-[rgba(255,255,255,0.04)]"
            style={{ borderColor: "var(--panel-border)", color: "var(--fg-dim)" }}>
            <RefreshCw size={13} className={loading ? "animate-spin" : ""} /> Refresh
          </button>
        </div>
      </div>

      {err && (
        <div className="mb-3 text-[12px] rounded-lg px-3 py-2"
          style={{ background: "rgba(196,96,126,0.12)", color: "var(--plum, #c4607e)" }}>{err}</div>
      )}

      <div className="grid gap-4" style={{ gridTemplateColumns: "minmax(230px, 300px) 1fr" }}>
        {/* ── roster ─────────────────────────────────────────────── */}
        <div className="rounded-2xl border overflow-hidden flex flex-col"
          style={{ borderColor: "var(--panel-border)", background: "var(--panel, rgba(255,255,255,0.02))", maxHeight: 660 }}>
          <div className="p-2.5 border-b flex items-center gap-2" style={{ borderColor: "var(--panel-border)" }}>
            <Search size={13} className="text-[var(--fg-dim)]" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Find a bot…"
              className="bg-transparent outline-none text-[12px] w-full text-[var(--fg)]" />
          </div>
          <div className="overflow-y-auto flex-1">
            {loading && <div className="p-4 text-[12px] text-[var(--fg-dim)]">Reading the roster…</div>}
            {shown.map((b) => {
              const on = b.name === sel;
              const busy = live?.status === "running" && live.to === b.name;
              return (
                <button key={b.name} onClick={() => setSel(b.name)}
                  className="w-full text-left px-2.5 py-2.5 flex items-start gap-2.5 border-b transition"
                  style={{
                    borderColor: "var(--panel-border)",
                    background: on ? "rgba(96,165,250,0.10)" : "transparent",
                  }}>
                  <Avatar shape={b.avatar.shape} color={b.avatar.color} busy={busy} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[13px] font-medium truncate text-[var(--fg)]">{b.name}</span>
                      {b.active && <span className="text-[9px] px-1.5 rounded-full"
                        style={{ background: "rgba(90,184,150,0.18)", color: "var(--emerald, #5ab896)" }}>active</span>}
                    </div>
                    <div className="text-[11px] text-[var(--fg-dim)] truncate">
                      {b.lastMessage || b.title}
                    </div>
                    <div className="text-[10px] text-[var(--fg-dim)] mt-0.5 flex items-center gap-2 opacity-70">
                      <span>{fmtAgo(b.lastActive)}</span>
                      {b.routines > 0 && <span className="flex items-center gap-0.5"><Clock size={9} />{b.routines}</span>}
                      {b.inboxCount > 0 && <span className="flex items-center gap-0.5"><Inbox size={9} />{b.inboxCount}</span>}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* ── the selected bot ───────────────────────────────────── */}
        <div className="rounded-2xl border flex flex-col min-h-0"
          style={{ borderColor: "var(--panel-border)", background: "var(--panel, rgba(255,255,255,0.02))", maxHeight: 660 }}>
          {!selected ? (
            <div className="p-6 text-[13px] text-[var(--fg-dim)]">Pick a bot on the left.</div>
          ) : (
            <>
              <div className="p-3.5 border-b flex items-start gap-3" style={{ borderColor: "var(--panel-border)" }}>
                <Avatar shape={selected.avatar.shape} color={selected.avatar.color} size={44}
                  busy={live?.status === "running" && live.to === selected.name} />
                <div className="min-w-0 flex-1">
                  <div className="text-[15px] font-medium text-[var(--fg)]">{selected.name}</div>
                  <div className="text-[12px] text-[var(--fg-dim)] line-clamp-2">{selected.title}</div>
                  <div className="text-[10px] mt-1 flex items-center gap-2 flex-wrap text-[var(--fg-dim)]">
                    <span className="px-1.5 py-0.5 rounded-full" style={{ background: "rgba(96,165,250,0.14)", color: ACCENT }}>
                      {selected.model}
                    </span>
                    <span>{selected.skills} skills</span>
                    <span>{selected.sessions} chats</span>
                  </div>
                </div>
                <button onClick={() => setShowRoutine(true)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full border text-[11px]"
                  style={{ borderColor: "var(--panel-border)", color: "var(--fg-dim)" }}>
                  <Clock size={12} /> New routine
                </button>
              </div>

              <div className="flex items-center gap-1 px-3 pt-2.5">
                {([["inbox", "Agent Inbox", <Inbox key="i" size={12} />],
                   ["routines", `Routines${selRoutines.length ? ` (${selRoutines.length})` : ""}`, <Clock key="c" size={12} />],
                   ["soul", "SOUL.md", <ScrollText key="s" size={12} />]] as const).map(([k, label, icon]) => (
                  <button key={k} onClick={() => setPane(k as typeof pane)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11.5px] transition"
                    style={pane === k
                      ? { background: "rgba(96,165,250,0.16)", color: ACCENT }
                      : { color: "var(--fg-dim)" }}>
                    {icon}{label}
                  </button>
                ))}
              </div>

              <div ref={feedRef} className="flex-1 overflow-y-auto p-3.5 min-h-0">
                {pane === "inbox" && (
                  <>
                    {inbox.length === 0 && !live && (
                      <div className="text-[12px] text-[var(--fg-dim)]">
                        No messages yet. Send this bot something below — the first message creates its
                        persistent <b>Agent Inbox</b> thread, and everything after that appends to it.
                      </div>
                    )}
                    <div className="space-y-2.5">
                      {inbox.map((m, i) => (
                        <div key={i} className="rounded-xl px-3 py-2.5 text-[12.5px] leading-relaxed"
                          style={{
                            background: m.role === "user" ? "rgba(255,255,255,0.035)" : "rgba(96,165,250,0.07)",
                            border: "1px solid var(--panel-border)",
                          }}>
                          <div className="text-[10px] uppercase tracking-widest mb-1 flex items-center gap-1"
                            style={{ color: m.from ? "var(--emerald, #5ab896)" : "var(--fg-dim)" }}>
                            {m.from ? <><AtSign size={9} />from agent “{m.from}”</> : (m.role === "user" ? "you" : selected.name)}
                          </div>
                          <div className="whitespace-pre-wrap text-[var(--fg)]">{m.text.slice(0, 2200)}</div>
                        </div>
                      ))}
                      {live && (
                        <div className="rounded-xl px-3 py-2.5 text-[12.5px]"
                          style={{ background: "rgba(96,165,250,0.07)", border: "1px solid rgba(96,165,250,0.35)" }}>
                          <div className="text-[10px] uppercase tracking-widest mb-1 flex items-center gap-1.5" style={{ color: ACCENT }}>
                            {live.status === "running"
                              ? <><Loader2 size={10} className="animate-spin" />handed off to “{live.to}” — working…</>
                              : live.status === "failed" ? <>handoff to “{live.to}” failed</> : <><Zap size={10} />“{live.to}” reported back</>}
                          </div>
                          <div className="whitespace-pre-wrap text-[var(--fg)]">
                            {live.reply || live.error || `hermes -p ${live.to} chat -c "Agent Inbox" -q "[Message from agent '${live.from}'] …"`}
                          </div>
                        </div>
                      )}
                    </div>
                  </>
                )}

                {pane === "routines" && (
                  <div className="space-y-2">
                    {selRoutines.length === 0 && (
                      <div className="text-[12px] text-[var(--fg-dim)]">
                        No routines yet. A routine is a recurring job that runs as this bot and lands in
                        its own history — “summarise my inbox every morning”. Real Hermes cron underneath.
                      </div>
                    )}
                    {selRoutines.map((r) => (
                      <div key={r.id} className="rounded-xl px-3 py-2.5 border"
                        style={{ borderColor: "var(--panel-border)", background: "rgba(255,255,255,0.02)" }}>
                        <div className="flex items-center gap-2">
                          <span className="h-1.5 w-1.5 rounded-full shrink-0"
                            style={{ background: r.enabled ? "var(--emerald, #5ab896)" : "var(--fg-dim)" }} />
                          <span className="text-[12.5px] font-medium flex-1 truncate text-[var(--fg)]">{r.title}</span>
                          <button onClick={() => routineAction(r.id, "routine-toggle", !r.enabled)}
                            title={r.enabled ? "Pause" : "Resume"} className="p-1 rounded hover:bg-[rgba(255,255,255,0.06)]">
                            {r.enabled ? <Pause size={12} className="text-[var(--fg-dim)]" /> : <Play size={12} className="text-[var(--fg-dim)]" />}
                          </button>
                          <button onClick={() => routineAction(r.id, "routine-delete")}
                            title="Delete" className="p-1 rounded hover:bg-[rgba(255,255,255,0.06)]">
                            <Trash2 size={12} className="text-[var(--fg-dim)]" />
                          </button>
                        </div>
                        <div className="text-[10.5px] text-[var(--fg-dim)] mt-1 flex gap-3 flex-wrap">
                          <span className="font-mono">{r.schedule}</span>
                          {r.nextRun && <span>next {new Date(r.nextRun).toLocaleString()}</span>}
                          {r.lastStatus && <span>last {r.lastStatus}</span>}
                        </div>
                        <div className="text-[11px] text-[var(--fg-dim)] mt-1.5 line-clamp-2 opacity-80">{r.prompt}</div>
                      </div>
                    ))}
                  </div>
                )}

                {pane === "soul" && (
                  <pre className="text-[11.5px] whitespace-pre-wrap font-mono leading-relaxed text-[var(--fg-dim)]">
                    {soul || "No SOUL.md yet."}
                  </pre>
                )}
              </div>

              {/* send / @mention */}
              <div className="p-2.5 border-t" style={{ borderColor: "var(--panel-border)" }}>
                <div className="flex items-center gap-2">
                  <input
                    value={msg}
                    onChange={(e) => setMsg(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
                    placeholder={`Message ${sel} — or type @otherbot to hand it off`}
                    className="flex-1 bg-transparent outline-none text-[12.5px] px-2 py-2 rounded-lg border text-[var(--fg)]"
                    style={{ borderColor: "var(--panel-border)" }}
                  />
                  <button onClick={send} disabled={sending || !msg.trim()}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-[12px] font-medium disabled:opacity-40"
                    style={{ background: ACCENT, color: "#0b1020" }}>
                    {sending ? <Loader2 size={13} className="animate-spin" /> : <Send size={13} />}
                    {sending ? "Working" : "Send"}
                  </button>
                </div>
                {mention && (
                  <div className="text-[10.5px] mt-1.5 flex items-center gap-1" style={{ color: target === mention[1].toLowerCase() ? "var(--emerald, #5ab896)" : "var(--plum, #c4607e)" }}>
                    <AtSign size={10} />
                    {target === mention[1].toLowerCase()
                      ? `handing off to “${mention[1]}” — the reply comes back here`
                      : `no bot called “${mention[1]}” on the roster`}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {showNew && <NewBot onClose={() => setShowNew(false)} onDone={(n) => { setShowNew(false); refresh(); setSel(n); }} bots={bots} />}
      {showRoutine && selected && (
        <NewRoutine bot={selected.name} onClose={() => setShowRoutine(false)}
          onDone={() => { setShowRoutine(false); refresh(); setPane("routines"); }} />
      )}
    </div>
  );
}

// ── new bot ─────────────────────────────────────────────────────────────────
function NewBot({ onClose, onDone, bots }: { onClose: () => void; onDone: (n: string) => void; bots: Bot[] }) {
  const [name, setName] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [cloneFrom, setCloneFrom] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function create() {
    setBusy(true); setErr(null);
    try {
      const r = await (await fetch("/api/hermes/bots", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "create", name: name.trim().toLowerCase(), title, description, cloneFrom }),
      })).json();
      if (r.error) { setErr(r.error); setBusy(false); return; }
      onDone(r.name);
    } catch (e) { setErr(String(e)); setBusy(false); }
  }

  return (
    <Modal title="New bot" onClose={onClose}>
      <p className="text-[12px] text-[var(--fg-dim)] mb-3">
        Three boxes. Name, job title, what it does. That&apos;s the whole thing —
        Agent OS creates a real Hermes profile with its own memory, skills and chat.
      </p>
      <Field label="Name" hint="lowercase, no spaces — this is how you @mention it">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="researcher"
          className="w-full bg-transparent outline-none text-[13px] px-2.5 py-2 rounded-lg border text-[var(--fg)]"
          style={{ borderColor: "var(--panel-border)" }} />
      </Field>
      <Field label="Title">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Research bot"
          className="w-full bg-transparent outline-none text-[13px] px-2.5 py-2 rounded-lg border text-[var(--fg)]"
          style={{ borderColor: "var(--panel-border)" }} />
      </Field>
      <Field label="What&apos;s its job?">
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3}
          placeholder="Digs up facts, sources and competitor moves. Reports findings back with links."
          className="w-full bg-transparent outline-none text-[13px] px-2.5 py-2 rounded-lg border resize-none text-[var(--fg)]"
          style={{ borderColor: "var(--panel-border)" }} />
      </Field>
      <Field label="Clone from" hint="copies config, skills and credentials so it works on message one">
        <select value={cloneFrom} onChange={(e) => setCloneFrom(e.target.value)}
          className="w-full bg-[var(--panel,#161219)] text-[13px] px-2.5 py-2 rounded-lg border text-[var(--fg)]"
          style={{ borderColor: "var(--panel-border)" }}>
          <option value="">Active profile (default)</option>
          {bots.map((b) => <option key={b.name} value={b.name}>{b.name}</option>)}
        </select>
      </Field>
      {err && <div className="text-[12px] mb-2" style={{ color: "var(--plum, #c4607e)" }}>{err}</div>}
      <button onClick={create} disabled={busy || !name.trim()}
        className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-[13px] font-medium disabled:opacity-40"
        style={{ background: ACCENT, color: "#0b1020" }}>
        {busy ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
        {busy ? "Creating the profile…" : "Create bot"}
      </button>
    </Modal>
  );
}

// ── new routine ─────────────────────────────────────────────────────────────
function NewRoutine({ bot, onClose, onDone }: { bot: string; onClose: () => void; onDone: () => void }) {
  const [title, setTitle] = useState("");
  const [schedule, setSchedule] = useState("0 7 * * *");
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function create() {
    setBusy(true); setErr(null);
    try {
      const r = await (await fetch("/api/hermes/bots", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "routine", bot, title, schedule, prompt }),
      })).json();
      if (r.error) { setErr(r.error); setBusy(false); return; }
      onDone();
    } catch (e) { setErr(String(e)); setBusy(false); }
  }

  return (
    <Modal title={`New routine for ${bot}`} onClose={onClose}>
      <p className="text-[12px] text-[var(--fg-dim)] mb-3">
        A routine is a job that runs on a schedule, as this bot. The result lands in
        the bot&apos;s own chat — so it&apos;s waiting for you when you click it.
      </p>
      <Field label="Routine name">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Morning inbox summary"
          className="w-full bg-transparent outline-none text-[13px] px-2.5 py-2 rounded-lg border text-[var(--fg)]"
          style={{ borderColor: "var(--panel-border)" }} />
      </Field>
      <Field label="When" hint="cron ('0 7 * * *') or plain ('every 6h')">
        <input value={schedule} onChange={(e) => setSchedule(e.target.value)}
          className="w-full bg-transparent outline-none text-[13px] px-2.5 py-2 rounded-lg border font-mono text-[var(--fg)]"
          style={{ borderColor: "var(--panel-border)" }} />
      </Field>
      <Field label="What should it do?">
        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={3}
          placeholder="Scan my inbox and give me a 5-bullet summary of anything that needs a reply today."
          className="w-full bg-transparent outline-none text-[13px] px-2.5 py-2 rounded-lg border resize-none text-[var(--fg)]"
          style={{ borderColor: "var(--panel-border)" }} />
      </Field>
      {err && <div className="text-[12px] mb-2" style={{ color: "var(--plum, #c4607e)" }}>{err}</div>}
      <button onClick={create} disabled={busy || !title.trim() || !prompt.trim()}
        className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-[13px] font-medium disabled:opacity-40"
        style={{ background: ACCENT, color: "#0b1020" }}>
        {busy ? <Loader2 size={14} className="animate-spin" /> : <Clock size={14} />}
        {busy ? "Scheduling…" : "Schedule it"}
      </button>
    </Modal>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="mb-3">
      <div className="text-[11px] mb-1 text-[var(--fg-dim)]">
        {label}{hint && <span className="opacity-60"> · {hint}</span>}
      </div>
      {children}
    </div>
  );
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(8,6,12,0.72)" }} onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl border p-5 max-h-[88vh] overflow-y-auto"
        style={{ borderColor: "var(--panel-border)", background: "var(--panel, #161219)" }}
        onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <div className="text-[14px] font-medium text-[var(--fg)]">{title}</div>
          <button onClick={onClose} className="p-1 rounded hover:bg-[rgba(255,255,255,0.06)]">
            <XIcon size={15} className="text-[var(--fg-dim)]" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
