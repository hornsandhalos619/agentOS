"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Blocks, ExternalLink, Loader2, Play, Power, Puzzle, Send, Terminal, FileText, RefreshCw, Boxes } from "lucide-react";

const ACCENT = "#4d6bfe";
const ACCENT2 = "#22d3ee";
const REPO = "https://github.com/deepseek-ai/deepseek-harness";

interface Status {
  installed: boolean; bin: string | null; version: string | null;
  keyed: boolean; webUp: boolean; url: string; home: string; workspace: string;
}
interface Plug { id: string; name: string }
interface Plugins { webOnly: Plug[]; counts: { web: number; headless: number } }

const TASKS = [
  "List the files in this folder and tell me what this project is.",
  "Write a file called notes.md summarising what DeepSeek Harness is, in 5 bullets.",
  "What is the house style for this workspace? Answer from the instruction files.",
];

export default function DeepSeekHarnessPanel() {
  const [st, setSt] = useState<Status | null>(null);
  const [plugins, setPlugins] = useState<Plugins | null>(null);
  const [booting, setBooting] = useState(false);
  const [task, setTask] = useState("");
  const [out, setOut] = useState("");
  const [running, setRunning] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [showStack, setShowStack] = useState(false);
  const outRef = useRef<HTMLPreElement>(null);

  const refresh = useCallback(async () => {
    const j = await fetch("/api/dsh/status", { cache: "no-store" }).then((r) => r.json()).catch(() => null);
    if (j) setSt(j);
  }, []);
  useEffect(() => { refresh(); const t = setInterval(refresh, 10_000); return () => clearInterval(t); }, [refresh]);
  useEffect(() => { if (outRef.current) outRef.current.scrollTop = outRef.current.scrollHeight; }, [out]);

  async function loadPlugins() {
    setShowStack(true);
    if (plugins) return;
    const j = await fetch("/api/dsh/plugins", { cache: "no-store" }).then((r) => r.json()).catch(() => null);
    if (j) setPlugins(j);
  }

  async function boot() {
    setBooting(true); setErr(null);
    const j = await fetch("/api/dsh/serve", { method: "POST" }).then((r) => r.json()).catch(() => null);
    if (j?.error) setErr(j.error);
    await refresh();
    setBooting(false);
  }

  async function run(t?: string) {
    const text = (t ?? task).trim();
    if (!text || running) return;
    setTask(""); setRunning(true); setErr(null);
    setOut(`❯ dsh --profile headless "${text}"\n\n`);
    try {
      const res = await fetch("/api/dsh/run", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ task: text }),
      });
      if (!res.body) throw new Error("no stream");
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n"); buf = lines.pop() || "";
        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const j = JSON.parse(line);
            if (j.type === "start") setOut((o) => o + `· working in ${j.cwd}\n\n`);
            else if (j.type === "text" || j.type === "info") setOut((o) => o + j.text);
            else if (j.type === "error") setErr(j.error);
            else if (j.type === "done") setOut((o) => o + `\n· exit ${j.code}\n`);
          } catch { /* partial */ }
        }
      }
    } catch (e) { setErr(String((e as Error).message || e)); }
    finally { setRunning(false); }
  }

  const ready = st?.installed && st?.keyed;

  return (
    <div className="space-y-4">
      {/* STATUS */}
      <div className="rounded-2xl border p-4" style={{ borderColor: "var(--panel-border)", background: "rgba(255,255,255,0.02)" }}>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="grid place-items-center w-10 h-10 rounded-xl shrink-0" style={{ background: `linear-gradient(135deg, ${ACCENT}, ${ACCENT2})`, color: "#04121f" }}><Blocks size={19} /></div>
          <div className="min-w-0">
            <div className="text-[10px] uppercase tracking-[0.18em]" style={{ color: ACCENT }}>DeepSeek Harness · everything is a plugin</div>
            <div className="text-[15px] font-semibold text-[var(--cream)] leading-tight">
              {st?.installed ? `dsh ${st.version || ""}` : "Not installed"}
              {st?.installed && <span className="text-[11px] font-normal text-[var(--cream-mute)] ml-2">MIT · open source</span>}
            </div>
          </div>
          <div className="ml-auto flex items-center gap-2 flex-wrap">
            {[
              { on: !!st?.installed, t: st?.installed ? "installed" : "not installed" },
              { on: !!st?.keyed, t: st?.keyed ? "keyed" : "no DeepSeek key" },
              { on: !!st?.webUp, t: st?.webUp ? "web UI live" : "web UI stopped" },
            ].map((c, i) => (
              <span key={i} className="inline-flex items-center gap-1.5 text-[11px] px-2.5 py-1 rounded-full whitespace-nowrap"
                style={{ background: c.on ? `${ACCENT}18` : "rgba(255,255,255,0.04)", border: `1px solid ${c.on ? ACCENT + "55" : "var(--line-soft)"}`, color: c.on ? ACCENT : "var(--cream-mute)" }}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: c.on ? ACCENT : "#6b7280" }} />{c.t}
              </span>
            ))}
          </div>
        </div>
        <p className="text-[13px] text-[var(--cream-soft)] mt-3 leading-relaxed max-w-[720px]">
          The harness is the body around the model — the tools, the memory, the sandbox, the loop, the screen.
          In this one <b className="text-[var(--cream)]">every single piece is a swappable plugin</b>, so the Agent OS can boot it as a
          full web app or drive it headless from here. It reads <b className="text-[var(--cream)]">AGENTS.md</b> and{" "}
          <b className="text-[var(--cream)]">CLAUDE.md</b>, so it inherits the same instructions your other agents already follow.
        </p>
        <div className="flex flex-wrap items-center gap-2 mt-3">
          <button onClick={boot} disabled={!ready || booting || st?.webUp}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-[12px] font-semibold"
            style={{ background: st?.webUp ? "rgba(255,255,255,0.05)" : `linear-gradient(135deg, ${ACCENT}, ${ACCENT2})`, color: st?.webUp ? "var(--cream-mute)" : "#04121f", opacity: !ready || booting ? 0.55 : 1 }}>
            {booting ? <Loader2 size={13} className="animate-spin" /> : <Power size={13} />}
            {st?.webUp ? "Harness running" : booting ? "Booting 129 plugins…" : "Start the harness"}
          </button>
          {st?.webUp && <a href={st.url} target="_blank" rel="noopener" className="inline-flex items-center gap-1.5 text-[11.5px] px-3 py-2 rounded-lg" style={{ border: "1px solid var(--line-soft)", color: ACCENT }}><ExternalLink size={12} /> Open in a tab</a>}
          <button onClick={loadPlugins} className="inline-flex items-center gap-1.5 text-[11.5px] px-3 py-2 rounded-lg" style={{ border: "1px solid var(--line-soft)", color: "var(--cream-mute)" }}><Puzzle size={12} /> See the plugin stack</button>
          <a href={REPO} target="_blank" rel="noopener" className="inline-flex items-center gap-1.5 text-[11.5px] px-3 py-2 rounded-lg" style={{ border: "1px solid var(--line-soft)", color: "var(--cream-mute)" }}><ExternalLink size={12} /> The repo</a>
          <button onClick={refresh} className="p-2 rounded-lg opacity-70 hover:opacity-100" style={{ border: "1px solid var(--line-soft)" }} title="Refresh"><RefreshCw size={12} color="var(--cream-mute)" /></button>
        </div>
        {!st?.installed && (
          <div className="mt-3 text-[11.5px] text-[var(--cream-mute)]">
            Install it once: <code className="mono px-1.5 py-0.5 rounded" style={{ background: "rgba(0,0,0,0.4)", color: "#bae6fd" }}>npx @deepseek-ai/dsh web</code>
          </div>
        )}
        {err && <div className="mt-3 text-[11.5px]" style={{ color: "var(--plum, #c4607e)" }}>{err}</div>}
      </div>

      {/* PLUGIN STACK — the claim, made literal */}
      {showStack && (
        <div className="rounded-2xl border p-4" style={{ borderColor: "var(--panel-border)", background: "rgba(255,255,255,0.02)" }}>
          <div className="flex items-center gap-2 mb-2">
            <Boxes size={14} color={ACCENT2} />
            <span className="text-[12.5px] font-medium text-[var(--cream)]">The plugin stack</span>
            {plugins ? (
              <span className="text-[11px] text-[var(--cream-mute)]">web {plugins.counts.web} · headless {plugins.counts.headless}</span>
            ) : <Loader2 size={12} className="animate-spin" color="var(--cream-mute)" />}
          </div>
          <p className="text-[12px] text-[var(--cream-soft)] leading-relaxed">
            Same harness, two profiles. The web app stacks <b className="text-[var(--cream)]">{plugins?.counts.web ?? "…"}</b> plugins;
            the headless runner stacks <b className="text-[var(--cream)]">{plugins?.counts.headless ?? "…"}</b>. Everything in the list below
            is what the web profile adds — and almost all of it is the screen itself. The interface is a plugin.
          </p>
          {plugins && (
            <div className="flex flex-wrap gap-1.5 mt-3 max-h-[190px] overflow-y-auto scroll">
              {plugins.webOnly.map((p) => (
                <span key={p.id} title={p.name} className="mono text-[10.5px] px-2 py-1 rounded-md"
                  style={{ background: p.id.startsWith("ui-") ? `${ACCENT}14` : "rgba(255,255,255,0.04)", border: `1px solid ${p.id.startsWith("ui-") ? ACCENT + "44" : "var(--line-soft)"}`, color: p.id.startsWith("ui-") ? ACCENT : "var(--cream-mute)" }}>
                  {p.id}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* DRIVE IT HEADLESS FROM THE OS */}
      <div className="rounded-2xl border overflow-hidden" style={{ borderColor: "var(--panel-border)", background: "rgba(255,255,255,0.02)" }}>
        <div className="px-4 py-2.5 border-b flex items-center gap-2" style={{ borderColor: "var(--line-soft)" }}>
          <Terminal size={13} color={ACCENT} />
          <span className="text-[11px] uppercase tracking-widest text-[var(--cream-mute)]">Run a job through the harness</span>
          <span className="ml-auto mono text-[10px] text-[var(--cream-mute)] truncate max-w-[46%]">{st?.workspace}</span>
        </div>
        <div className="p-4 space-y-3">
          <div className="flex flex-wrap gap-1.5">
            {TASKS.map((t) => (
              <button key={t} onClick={() => run(t)} disabled={!ready || running}
                className="text-[11px] px-2.5 py-1.5 rounded-full transition"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid var(--line-soft)", color: "var(--cream-mute)", opacity: ready && !running ? 1 : 0.5 }}>
                {t.length > 52 ? t.slice(0, 52) + "…" : t}
              </button>
            ))}
          </div>
          <div className="flex items-end gap-2">
            <textarea value={task} onChange={(e) => setTask(e.target.value)} rows={1} disabled={!ready}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); run(); } }}
              placeholder={ready ? "Give the harness a job — it works in its own folder…" : "Install dsh and add DEEPSEEK_API_KEY first"}
              className="flex-1 resize-none p-2.5 rounded-lg text-[13px]"
              style={{ background: "rgba(255,255,255,0.03)", border: "1px solid var(--panel-border)", color: "var(--cream)", opacity: ready ? 1 : 0.6 }} />
            <button onClick={() => run()} disabled={!ready || running || !task.trim()}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-[12px] font-semibold"
              style={{ background: `linear-gradient(135deg, ${ACCENT}, ${ACCENT2})`, color: "#04121f", opacity: !ready || running || !task.trim() ? 0.5 : 1 }}>
              {running ? <Loader2 size={13} className="animate-spin" /> : <Send size={13} />} Run
            </button>
          </div>
          {(out || running) && (
            <pre ref={outRef} className="mono text-[11.5px] rounded-lg p-3 max-h-[280px] overflow-auto whitespace-pre-wrap"
              style={{ background: "rgba(0,0,0,0.45)", border: "1px solid var(--panel-border)", color: "#bae6fd" }}>
              {out}{running && <span style={{ color: ACCENT }}>▌</span>}
            </pre>
          )}
          <div className="text-[11px] text-[var(--cream-mute)] flex items-center gap-1.5">
            <FileText size={11} /> Drop an <span className="mono">AGENTS.md</span> or <span className="mono">CLAUDE.md</span> in the folder and the harness reads it before it answers.
          </div>
        </div>
      </div>

      {/* THE HARNESS ITSELF, LIVE */}
      {st?.webUp && (
        <div className="rounded-2xl border overflow-hidden" style={{ borderColor: "var(--panel-border)", background: "rgba(0,0,0,0.22)" }}>
          <div className="px-4 py-2.5 border-b flex items-center gap-2" style={{ borderColor: "var(--line-soft)" }}>
            <Play size={13} color={ACCENT2} />
            <span className="text-[11px] uppercase tracking-widest text-[var(--cream-mute)]">The harness, live in the dashboard</span>
            <a href={st.url} target="_blank" rel="noopener" className="ml-auto text-[11px] inline-flex items-center gap-1" style={{ color: ACCENT }}>{st.url} <ExternalLink size={11} /></a>
          </div>
          <iframe title="DeepSeek Harness" src={st.url} className="w-full" style={{ height: "min(72vh, 720px)", border: 0, background: "#0b0b12" }} />
        </div>
      )}
    </div>
  );
}
