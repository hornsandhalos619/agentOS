import { NextResponse } from "next/server";
import { run } from "@/lib/runner";
import { hermesHome } from "@/lib/config";
import { existsSync } from "node:fs";
import path from "node:path";
import HERMES_COMMANDS from "./hermes-commands.json";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Strip ALL common ANSI escape sequences (CSI, OSC, simple SGR) — not just `[...m`.
// Otherwise terminal control codes can eat the reply or leave it looking empty.
const ANSI_STRIP = /\x1b\[[0-9;?]*[a-zA-Z]|\x1b\]\d+;[^\x07\x1b]*(\x07|\x1b\\)/g;

const TIMEOUT_MS = 6 * 60 * 1000; // 6 min — multi-step agentic tasks (skill invocations, video edits) routinely exceed 2 min.

interface ChatMsg { role: "user" | "assistant" | "system"; text: string; }

// `hermes -z` is single-query mode — it has no memory of earlier turns, so a
// back-and-forth chat felt like talking to someone with amnesia. We give it the
// recent conversation by packing it into the prompt (same approach the Claude,
// Kimi, Free-Claude and Grok chat tabs use). Trimmed to fit the context budget.
function buildPromptWithHistory(history: ChatMsg[], current: string): string {
  if (!Array.isArray(history) || !history.length) return current;
  const recent = history.slice(-24);
  const lines: string[] = [
    "The following is the prior conversation between you and the user.",
    "Read it, then answer the user's latest message at the bottom.",
    "",
    "--- prior conversation ---",
  ];
  let bytes = 0;
  const MAX_BYTES = 8000;
  for (const m of recent) {
    if (!m || typeof m.text !== "string") continue;
    const role = m.role === "user" ? "User" : m.role === "assistant" ? "Assistant" : "System";
    const line = `${role}: ${m.text}`;
    if (bytes + line.length > MAX_BYTES) { lines.push("…[earlier turns trimmed]"); break; }
    lines.push(line);
    bytes += line.length;
  }
  lines.push("--- end prior conversation ---", "", `User: ${current}`, "Assistant:");
  return lines.join("\n");
}


// ── Slash commands ─────────────────────────────────────────────────────────
// Hermes' 90+ slash commands (/learn, /compress, /memory …) are dispatched by the
// interactive TUI and the gateway — `-z` one-shot mode has NO dispatcher, so typed
// into this chat they reach the model as plain text. Whether anything happens then
// depends on the model's temperament: DeepSeek improvised /learn with its file
// tools; Qwen 3.8 explained that no such skill exists. Same input, opposite
// outcomes. We make it deterministic: recognise the command, and hand the model an
// explicit executable brief for it (rich one for /learn, generic for the rest).
const COMMANDS: Record<string, string> = HERMES_COMMANDS as Record<string, string>;

function slashShim(prompt: string, profile: string): string | null {
  const m = prompt.match(/^\/([a-z0-9-]+)(?:\s+([\s\S]*))?$/i);
  if (!m) return null;
  const name = m[1].toLowerCase();
  const args = (m[2] ?? "").trim();
  if (!(name in COMMANDS)) return null; // unknown /word — let the model see it raw
  const skillsDir = path.join(hermesHome(), "profiles", profile, "skills");
  if (name === "learn") {
    return [
      `The user invoked Hermes' built-in /learn command: "${COMMANDS.learn}".`,
      "Execute it now — do not claim the command or skill does not exist; you ARE its executor in this mode.",
      `SOURCE TO LEARN FROM: ${args || "the prior conversation above"}`,
      "Steps:",
      "1. Ingest the source (fetch the URL / read the dir / re-read this chat).",
      "2. Distill it into a reusable skill: what it teaches, exact commands/config that were VERIFIED to work, traps + fixes. Strip sales copy.",
      `3. Write it as a SKILL.md with YAML frontmatter (name, description, version, author, metadata.hermes.tags) under ${skillsDir}/<category>/<kebab-slug>/SKILL.md — pick the closest existing category dir, create the slug dir.`,
      "4. Reply with: the skill name, the absolute path written, and 3 bullet points of what it captures.",
    ].join("\n");
  }
  // Generic bridge for every other registered command: tell the model exactly what
  // was invoked so it performs the equivalent with its tools — or says plainly
  // which surface (Control Room / terminal TUI) carries it when it truly can't.
  return [
    `The user invoked Hermes' built-in /${name} command${args ? ` with arguments: "${args}"` : ""}.`,
    `Its registered purpose: "${COMMANDS[name]}".`,
    "You are running headless (one-shot), so the TUI dispatcher did not handle it. Perform the equivalent of this command now using your tools if that is possible headlessly.",
    "If it genuinely requires the interactive client (UI redraw, session navigation), say so in one sentence and point the user to the Control Room tab or `hermes` in a terminal — do not claim the command does not exist.",
  ].join("\n");
}

export async function POST(req: Request) {
  const { prompt, profile, history } = await req.json();
  if (typeof prompt !== "string" || prompt.length === 0) {
    return NextResponse.json({ error: "missing prompt" }, { status: 400 });
  }
  if (prompt.length > 16_000) {
    return NextResponse.json({ error: "prompt too long" }, { status: 413 });
  }
  // Optional profile = chat as a specific Hermes employee (seo-writer, etc.).
  if (profile !== undefined && (typeof profile !== "string" || !/^[a-zA-Z0-9_-]{1,64}$/.test(profile))) {
    return NextResponse.json({ error: "bad profile" }, { status: 400 });
  }

  // hermes -z PROMPT  — single-query non-interactive mode.
  // --yolo + --accept-hooks are ESSENTIAL for headless/VPS runs: without them,
  // Hermes blocks on an interactive approval/hook-confirmation prompt it can't
  // display in oneshot mode, and the dashboard just sees blank output. (Matches
  // the flags Goal Mode already uses.) If the reply is STILL blank after this,
  // it's almost always auth — run `hermes status` and check the provider shows
  // a ✓ for its API key.
  // A stale/deleted profile selection (e.g. a "kimi" pill left in localStorage from an
  // earlier setup) must NOT hard-fail every message with "Profile 'kimi' does not exist".
  // Only pass --profile when that profile actually exists; otherwise fall back to Hermes'
  // default active profile so the chat still works.
  // v0.19 REALITY CHECK (2026-07-31): the HERMES_PROFILE env var is IGNORED by Hermes —
  // `HERMES_PROFILE=x hermes status` silently reports the ACTIVE profile's model, so every
  // profile pill was cosmetic and answers came from `julian` (kimi-k3). Only the `-p` FLAG
  // selects a profile. -p scopes auth per-profile, so each profile's auth.json now carries
  // the Portal OAuth block (propagated from julian) — verified `hermes -p hermes-cloud status`
  // shows Nous Portal ✓ logged in.
  const profileArgs: string[] = profile && existsSync(path.join(hermesHome(), "profiles", profile))
    ? ["-p", profile]
    : [];
  // Pack the recent conversation in so follow-ups keep context (no more amnesia).
  const activeProfile = profileArgs.length ? profileArgs[1] : "julian";
  const shimmed = slashShim(prompt.trim(), activeProfile);
  const fullPrompt = buildPromptWithHistory(history, shimmed ?? prompt);
  const out = await run("hermes", [...profileArgs, "-z", fullPrompt, "--yolo", "--accept-hooks"], { timeoutMs: TIMEOUT_MS });

  const text = out.stdout.replace(ANSI_STRIP, "").trim();
  const stderrClean = out.stderr.replace(ANSI_STRIP, "").trim();

  // If Hermes produced no usable text, build a diagnostic reply instead of returning the opaque "(no response)".
  let diagnostic: string | null = null;
  if (!text) {
    const seconds = (out.durationMs / 1000).toFixed(1);
    const probableTimeout = out.durationMs >= TIMEOUT_MS - 2_000;
    const lines: string[] = [];
    lines.push(probableTimeout
      ? `⏱ Hermes was killed after ${seconds}s — the task likely needed longer than the ${Math.round(TIMEOUT_MS/60000)}-minute budget. Multi-step agentic tasks (skill invocations, video edits) often exceed this.`
      : `⚠ Hermes finished in ${seconds}s with exit ${out.code} but no stdout.`
    );
    if (stderrClean) {
      lines.push("");
      lines.push("─── stderr ───");
      lines.push(stderrClean.length > 4000 ? stderrClean.slice(-4000) : stderrClean);
    } else if (probableTimeout) {
      // A timeout with clean stderr is NOT an auth problem — sending the user to
      // `hermes status` here (as we used to) chases a config issue that doesn't exist.
      lines.push("");
      lines.push("Try a tighter ask, or run long jobs via Goal Mode / the Control Room — those have no 6-minute ceiling.");
    } else {
      lines.push("");
      lines.push("(no stderr either) — blank output with no error is almost always auth or provider config:");
      lines.push("  1. Run `hermes status` — does your provider show a ✓ next to its API key?");
      lines.push("  2. If ✗, run `hermes login` (or set the key in ~/.hermes/.env) for that provider.");
      lines.push("  3. Check the Model + Provider lines in `hermes status` are a real, supported combo.");
      lines.push("  4. Then `hermes doctor` for a full config check.");
    }
    diagnostic = lines.join("\n");
  }

  return NextResponse.json({
    ok: out.ok && !!text,
    text: text || diagnostic || "(no response)",
    empty: !text,
    durationMs: out.durationMs,
    exitCode: out.code,
    timedOut: !text && out.durationMs >= TIMEOUT_MS - 2_000,
    stderr: stderrClean, // full, no trunc — useful for diagnosing
  });
}
