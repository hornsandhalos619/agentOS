import { NextResponse } from "next/server";
import { spawn } from "node:child_process";
import { mkdir, readFile, writeFile, readdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import os from "node:os";
import {
  listBots, listRoutines, readInbox, PROFILES_DIR, hermesBin, validBotName,
  seedCredentials, writeSoul, inboxProtocol, INBOX_TITLE,
} from "@/lib/hermesBots";
import { hermesHome } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET  /api/hermes/bots                       — roster + routines
// GET  /api/hermes/bots?bot=<name>            — one bot's Agent Inbox + routines
// GET  /api/hermes/bots?handoff=<id>          — status of a bot-to-bot handoff
// POST /api/hermes/bots  { action: "send" | "create" | "routine" | "routine-toggle" | "routine-delete" }

const HANDOFF_DIR = path.join(os.homedir(), ".agentic-os", "bots", "handoffs");

interface Handoff {
  id: string; from: string; to: string; message: string;
  status: "running" | "done" | "failed";
  startedAt: number; finishedAt?: number; reply: string; error?: string;
}

async function readHandoff(id: string): Promise<Handoff | null> {
  try { return JSON.parse(await readFile(path.join(HANDOFF_DIR, `${id}.json`), "utf8")); }
  catch { return null; }
}
async function saveHandoff(h: Handoff): Promise<void> {
  await mkdir(HANDOFF_DIR, { recursive: true });
  await writeFile(path.join(HANDOFF_DIR, `${h.id}.json`), JSON.stringify(h, null, 2), "utf8");
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const handoff = url.searchParams.get("handoff");
  if (handoff) {
    const h = await readHandoff(handoff);
    return NextResponse.json(h ? { handoff: h } : { error: "not found" }, { status: h ? 200 : 404 });
  }

  const bot = url.searchParams.get("bot");
  if (bot) {
    if (!validBotName(bot)) return NextResponse.json({ error: "bad name" }, { status: 400 });
    const dir = path.join(PROFILES_DIR(), bot);
    if (!existsSync(dir)) return NextResponse.json({ error: "no such bot" }, { status: 404 });
    let soul = "";
    try { soul = await readFile(path.join(dir, "SOUL.md"), "utf8"); } catch { /* none */ }
    const inbox = await readInbox(dir, 40);
    const routines = (await listRoutines()).filter((r) => r.bot === bot.toLowerCase());
    // recent handoffs involving this bot
    let handoffs: Handoff[] = [];
    try {
      const files = existsSync(HANDOFF_DIR) ? await readdir(HANDOFF_DIR) : [];
      const all = await Promise.all(files.filter((f) => f.endsWith(".json"))
        .map((f) => readHandoff(f.replace(/\.json$/, ""))));
      handoffs = (all.filter(Boolean) as Handoff[])
        .filter((h) => h.to === bot || h.from === bot)
        .sort((a, b) => b.startedAt - a.startedAt).slice(0, 10);
    } catch { /* none */ }
    return NextResponse.json({ bot, soul: soul.slice(0, 8000), inbox, routines, handoffs });
  }

  const [bots, routines] = await Promise.all([listBots(), listRoutines()]);
  return NextResponse.json({ bots, routines, hermes: Boolean(hermesBin()) });
}

export async function POST(req: Request) {
  const bin = hermesBin();
  if (!bin) return NextResponse.json({ error: "hermes CLI not installed" }, { status: 503 });
  const body = await req.json().catch(() => ({}));
  const action = String(body.action ?? "");

  // ── bot-to-bot handoff ────────────────────────────────────────────────────
  // The real thing the plugin does:
  //   hermes -p <to> chat --in ~ -c "Agent Inbox" -q "[Message from agent 'from'] ..."
  if (action === "send") {
    const to = String(body.to ?? "").toLowerCase();
    const from = String(body.from ?? "you").toLowerCase();
    const message = String(body.message ?? "").trim();
    if (!validBotName(to)) return NextResponse.json({ error: "bad target bot" }, { status: 400 });
    if (!existsSync(path.join(PROFILES_DIR(), to))) return NextResponse.json({ error: "no such bot" }, { status: 404 });
    if (!message) return NextResponse.json({ error: "message required" }, { status: 400 });

    const id = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    const h: Handoff = { id, from, to, message, status: "running", startedAt: Date.now(), reply: "" };
    await saveHandoff(h);

    const tagged = `[Message from agent '${from}'] ${message}`;
    // -c "Agent Inbox" appends to the one persistent inbox thread. If the bot
    // has never been messaged, that session does not exist yet — fall back to a
    // fresh session and rename it, which is the documented bootstrap.
    const run = (args: string[]) => new Promise<{ code: number; out: string }>((resolve) => {
      const child = spawn(bin, args, { cwd: os.homedir(), env: { ...process.env } });
      let out = "";
      child.stdout.on("data", (d) => { out += d.toString(); });
      child.stderr.on("data", (d) => { out += d.toString(); });
      child.on("close", (code) => resolve({ code: code ?? 1, out }));
      child.on("error", (e) => resolve({ code: 1, out: String(e) }));
    });

    (async () => {
      let res = await run(["-p", to, "chat", "--in", os.homedir(), "-c", INBOX_TITLE, "-Q", "-q", tagged]);
      let bootstrapped = false;
      if (/No session found matching/i.test(res.out)) {
        // bootstrap: new session, then rename it to the inbox title
        bootstrapped = true;
        res = await run(["-p", to, "chat", "--in", os.homedir(), "-Q", "-q", tagged]);
        const sid = /session_id:\s*([a-z0-9_]+)/i.exec(res.out)?.[1];
        if (sid) await run(["-p", to, "sessions", "rename", sid, INBOX_TITLE]);
      }
      const clean = res.out
        .split("\n")
        .filter((l) => !/^(Warning:|\s*⚠|↻ Resumed session|session_id:)/.test(l))
        .join("\n").trim();
      const done: Handoff = {
        ...h,
        status: res.code === 0 ? "done" : "failed",
        finishedAt: Date.now(),
        reply: clean.slice(0, 12000),
        error: res.code === 0 ? undefined : `exit ${res.code}${bootstrapped ? " (after inbox bootstrap)" : ""}`,
      };
      await saveHandoff(done);
    })();

    return NextResponse.json({ handoff: h });
  }

  // ── create a bot ──────────────────────────────────────────────────────────
  if (action === "create") {
    const name = String(body.name ?? "").trim().toLowerCase();
    const title = String(body.title ?? "").trim();
    const description = String(body.description ?? "").trim();
    const cloneFrom = String(body.cloneFrom ?? "").trim().toLowerCase();
    if (!validBotName(name)) {
      return NextResponse.json({ error: "Name must be lowercase letters, numbers, - or _ (2–31 chars)." }, { status: 400 });
    }
    if (existsSync(path.join(PROFILES_DIR(), name))) {
      return NextResponse.json({ error: `A bot called "${name}" already exists.` }, { status: 409 });
    }
    const desc = [title, description].filter(Boolean).join(" — ") || `Bot ${name}`;
    const args = ["profile", "create", name, "--description", desc];
    if (cloneFrom && existsSync(path.join(PROFILES_DIR(), cloneFrom))) args.push("--clone-from", cloneFrom);

    const out = await new Promise<{ code: number; out: string }>((resolve) => {
      const child = spawn(bin, args, { cwd: os.homedir(), env: { ...process.env } });
      let o = "";
      child.stdout.on("data", (d) => { o += d.toString(); });
      child.stderr.on("data", (d) => { o += d.toString(); });
      child.on("close", (code) => resolve({ code: code ?? 1, out: o }));
      child.on("error", (e) => resolve({ code: 1, out: String(e) }));
    });
    if (out.code !== 0 || !existsSync(path.join(PROFILES_DIR(), name))) {
      return NextResponse.json({ error: out.out.slice(-800) || "profile create failed" }, { status: 500 });
    }

    // A brand-new profile has no credentials; carry them from the source so the
    // bot can actually answer on its first message.
    let activeName = "julian";
    try { activeName = (await readFile(path.join(hermesHome(), "active_profile"), "utf8")).trim() || activeName; } catch { /* */ }
    const seeded = await seedCredentials(cloneFrom || activeName, name);

    // SOUL.md = identity + the bot-to-bot protocol (what the plugin writes).
    const soulBody = String(body.soul ?? "").trim() || [
      `# ${title || name}`,
      "",
      description || `You are '${name}', an agent on this roster.`,
      "",
    ].join("\n");
    await writeSoul(name, `${soulBody}\n\n${inboxProtocol(name)}`);

    return NextResponse.json({ ok: true, name, seeded });
  }

  // ── routines (real Hermes cron, namespaced [bot:<name>]) ──────────────────
  if (action === "routine") {
    const bot = String(body.bot ?? "").toLowerCase();
    const title = String(body.title ?? "").trim();
    const schedule = String(body.schedule ?? "").trim();
    const prompt = String(body.prompt ?? "").trim();
    if (!validBotName(bot)) return NextResponse.json({ error: "bad bot" }, { status: 400 });
    if (!title || !schedule || !prompt) return NextResponse.json({ error: "title, schedule and prompt are required" }, { status: 400 });

    const out = await new Promise<{ code: number; out: string }>((resolve) => {
      const child = spawn(bin, ["cron", "create", schedule, prompt, "--name", `[bot:${bot}] ${title}`], {
        cwd: os.homedir(), env: { ...process.env },
      });
      let o = "";
      child.stdout.on("data", (d) => { o += d.toString(); });
      child.stderr.on("data", (d) => { o += d.toString(); });
      child.on("close", (code) => resolve({ code: code ?? 1, out: o }));
      child.on("error", (e) => resolve({ code: 1, out: String(e) }));
    });
    if (out.code !== 0) return NextResponse.json({ error: out.out.slice(-600) }, { status: 500 });
    return NextResponse.json({ ok: true, out: out.out.trim().slice(-600) });
  }

  if (action === "routine-toggle" || action === "routine-delete") {
    const id = String(body.id ?? "").trim();
    if (!/^[a-z0-9]+$/i.test(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
    const sub = action === "routine-delete" ? "remove" : (body.enable ? "resume" : "pause");
    const out = await new Promise<{ code: number; out: string }>((resolve) => {
      const child = spawn(bin, ["cron", sub, id], { cwd: os.homedir(), env: { ...process.env } });
      let o = "";
      child.stdout.on("data", (d) => { o += d.toString(); });
      child.stderr.on("data", (d) => { o += d.toString(); });
      child.on("close", (code) => resolve({ code: code ?? 1, out: o }));
      child.on("error", (e) => resolve({ code: 1, out: String(e) }));
    });
    if (out.code !== 0) return NextResponse.json({ error: out.out.slice(-600) }, { status: 500 });
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: `unknown action "${action}"` }, { status: 400 });
}
