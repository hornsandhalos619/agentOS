import { NextResponse } from "next/server";
import fs from "fs";
import os from "os";
import path from "path";
import { config } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// OpenMausBot bridge — the OS talks to the local harness server that the
// OpenMausBot app (or `pnpm dev:server`) already runs on 127.0.0.1:8799.
// Nothing is re-implemented here: the roster, the threads and the turns all
// live in ~/.openmausbot, so the app and this tab are always the same state.
//
// The one thing the OS adds is SHARED MEMORY: with `memory: true`, a turn is
// prefixed with the Obsidian vault contract, so an OpenMausBot bot reads and
// writes the same brain as Hermes, Claude and every other agent here.

const HARNESS = process.env.OPENMAUSBOT_URL?.trim() || "http://127.0.0.1:8799";
// The member's vault (config.vaultRoot / auto-detect), falling back to the common default.
const VAULT = config.vaultRoot || path.join(os.homedir(), "Documents", "Obsidian Vault");

function today(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

const WORKSPACE = path.join(os.homedir(), ".agentic-os", "openmausbot-workspace");
const slug = (name: string) => name.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "bot";

/** The shared-brain contract every OS agent gets. Same vault, same rules. */
export function memoryPreamble(botName = ""): string {
  return [
    "[Agent OS shared memory — every agent on this Mac reads and writes ONE vault]",
    `Vault: ${VAULT}`,
    `Workspace: ${path.join(WORKSPACE, slug(botName))} — put anything you build or write here so the OS can preview it.`,
    `Before you work, read what is relevant: the owner's profile note${config.userName && config.userName !== "You" ? ` (e.g. \`04 Resources/About ${config.userName}.md\`)` : " (e.g. under `04 Resources/`)"}, today's note in \`01 Daily/\`,`,
    "and the recent files in `Agentic OS/Memories/`. Search the vault before you assume anything.",
    `When you are done, append 2-3 lines to \`Agentic OS/Memories/${today()}.md\` (create it if missing):`,
    "what you were asked, what you found, and anything the next agent should know.",
    "Never store secrets. Keep it short.",
    "",
    "--- the actual job ---",
    "",
  ].join("\n");
}

async function harness(pathname: string, init?: RequestInit) {
  const r = await fetch(`${HARNESS}${pathname}`, { ...init, cache: "no-store" });
  const text = await r.text();
  let body: unknown = {};
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
  return { ok: r.ok, status: r.status, body };
}

// GET /api/openmausbot  → harness health + provider instances + the bot roster
export async function GET() {
  try {
    const [health, instances, bots] = await Promise.all([
      harness("/api/health"),
      harness("/api/instances"),
      harness("/api/bots"),
    ]);
    return NextResponse.json({
      connected: health.ok,
      harness: HARNESS,
      health: health.body,
      instances: (instances.body as { instances?: unknown[] }).instances ?? [],
      bots: (bots.body as { bots?: unknown[] }).bots ?? [],
      vault: fs.existsSync(VAULT) ? VAULT : null,
      memoryFile: `Agentic OS/Memories/${today()}.md`,
    });
  } catch (e) {
    return NextResponse.json({
      connected: false,
      harness: HARNESS,
      error: `OpenMausBot harness is not answering on ${HARNESS}. Open the OpenMausBot app (or run \`pnpm dev:server\` in ~/OpenMausBot).`,
      detail: String(e).slice(0, 200),
      bots: [], instances: [],
    }, { status: 200 });
  }
}

// POST /api/openmausbot  { action: "send" | "create" | "rename" | "model" | "respond" | "interrupt", ... }
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const action = String(body.action ?? "");
  try {
    if (action === "send") {
      const botId = String(body.botId ?? "");
      const raw = String(body.text ?? "").trim();
      if (!botId || !raw) return NextResponse.json({ error: "botId and text required" }, { status: 400 });
      let botName = "";
      if (body.memory) {
        const list = await harness("/api/bots");
        botName = ((list.body as { bots?: { id: string; name: string }[] }).bots ?? []).find((b) => b.id === botId)?.name ?? "";
      }
      const text = body.memory ? memoryPreamble(botName) + raw : raw;
      const r = await harness(`/api/bots/${botId}/messages`, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ text }),
      });
      return NextResponse.json(r.body, { status: r.status });
    }

    if (action === "create") {
      const made = await harness("/api/bots", { method: "POST" });
      const bot = (made.body as { bot?: { id: string } }).bot;
      if (!bot) return NextResponse.json({ error: "harness would not create a bot" }, { status: 502 });
      const patch: Record<string, unknown> = {};
      if (body.name) patch.name = String(body.name);
      if (body.description) patch.description = String(body.description);
      if (body.modelSelection) patch.modelSelection = body.modelSelection;
      if (Object.keys(patch).length) await harness(`/api/bots/${bot.id}`, {
        method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(patch),
      });
      return NextResponse.json({ bot: { ...bot, ...patch } }, { status: 201 });
    }

    if (action === "rename" || action === "model") {
      const botId = String(body.botId ?? "");
      if (!botId) return NextResponse.json({ error: "botId required" }, { status: 400 });
      const patch = action === "rename"
        ? { name: String(body.name ?? "") }
        : { modelSelection: body.modelSelection };
      const r = await harness(`/api/bots/${botId}`, {
        method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(patch),
      });
      return NextResponse.json(r.body, { status: r.status });
    }

    if (action === "respond") {
      const botId = String(body.botId ?? "");
      const r = await harness(`/api/bots/${botId}/respond`, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ requestId: body.requestId, behavior: body.behavior, message: body.message }),
      });
      return NextResponse.json(r.body, { status: r.status });
    }

    if (action === "interrupt") {
      const r = await harness(`/api/bots/${String(body.botId ?? "")}/interrupt`, { method: "POST" });
      return NextResponse.json(r.body, { status: r.status });
    }

    return NextResponse.json({ error: `unknown action "${action}"` }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ error: `harness unreachable on ${HARNESS}`, detail: String(e).slice(0, 200) }, { status: 503 });
  }
}
