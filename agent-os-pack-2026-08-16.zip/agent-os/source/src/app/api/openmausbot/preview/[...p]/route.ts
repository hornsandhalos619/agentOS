import fs from "fs";
import os from "os";
import path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const WORKSPACE = path.join(os.homedir(), ".agentic-os", "openmausbot-workspace");
const TYPES: Record<string, string> = {
  ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript",
  ".json": "application/json", ".md": "text/plain; charset=utf-8", ".txt": "text/plain; charset=utf-8",
  ".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp", ".svg": "image/svg+xml",
};

// Serve a file a bot built, so the OS can preview it live in an iframe.
export async function GET(_req: Request, ctx: { params: Promise<{ p: string[] }> }) {
  const { p } = await ctx.params;
  const rel = (p ?? []).join("/");
  const file = path.resolve(WORKSPACE, rel);
  if (!file.startsWith(WORKSPACE + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    return new Response("not found", { status: 404 });
  }
  return new Response(new Uint8Array(fs.readFileSync(file)), {
    headers: { "content-type": TYPES[path.extname(file).toLowerCase()] ?? "application/octet-stream", "cache-control": "no-store" },
  });
}
