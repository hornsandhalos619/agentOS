import { NextResponse } from "next/server";
import fs from "fs";
import os from "os";
import path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Everything the bots build lands in one place the OS can browse and preview.
// Same workspace pattern as every other agent here: a project folder per bot,
// HTML previewed live, markdown read inline.
export const WORKSPACE = path.join(os.homedir(), ".agentic-os", "openmausbot-workspace");

const TEXT = new Set([".md", ".txt", ".json", ".csv"]);

export async function GET() {
  try { fs.mkdirSync(WORKSPACE, { recursive: true }); } catch { /* exists */ }
  const projects = fs.readdirSync(WORKSPACE, { withFileTypes: true })
    .filter((d) => d.isDirectory() && !d.name.startsWith("."))
    .map((d) => {
      const dir = path.join(WORKSPACE, d.name);
      const files = fs.readdirSync(dir, { withFileTypes: true })
        .filter((f) => f.isFile() && !f.name.startsWith("."))
        .map((f) => {
          const p = path.join(dir, f.name);
          const st = fs.statSync(p);
          const ext = path.extname(f.name).toLowerCase();
          return {
            rel: f.name, bytes: st.size, mtime: st.mtimeMs, ext,
            // small text files come back inline so the panel can show the work itself
            text: TEXT.has(ext) && st.size < 60_000 ? fs.readFileSync(p, "utf8") : null,
          };
        })
        .sort((a, b) => b.mtime - a.mtime);
      return {
        project: d.name,
        mtime: files[0]?.mtime ?? fs.statSync(dir).mtimeMs,
        files,
        html: files.filter((f) => f.ext === ".html").map((f) => f.rel),
      };
    })
    .filter((p) => p.files.length)
    .sort((a, b) => b.mtime - a.mtime);
  return NextResponse.json({ workspace: WORKSPACE, projects });
}
