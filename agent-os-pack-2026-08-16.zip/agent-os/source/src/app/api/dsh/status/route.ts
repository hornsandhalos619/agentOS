import { NextResponse } from "next/server";
import { deepseekKey, dshBin, dshVersion, DSH_HOME, DSH_URL, DSH_WORKSPACE, webUp } from "@/lib/dsh";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET /api/dsh/status — is DeepSeek Harness installed, keyed, and serving?
export async function GET() {
  const bin = dshBin();
  const [version, up] = await Promise.all([bin ? dshVersion() : null, webUp()]);
  return NextResponse.json({
    installed: !!bin,
    bin,
    version,
    keyed: !!deepseekKey(),
    webUp: up,
    url: DSH_URL,
    home: DSH_HOME,
    workspace: DSH_WORKSPACE,
  });
}
