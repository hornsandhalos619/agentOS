import { spawn } from "node:child_process";
import { mkdir } from "node:fs/promises";
import path from "node:path";
import { deepseekKey, dshBin, dshEnv, DSH_WORKSPACE } from "@/lib/dsh";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 600;

// POST /api/dsh/run { task, project? } — drive the harness headless from the OS.
//
// `dsh --profile headless "<task>"` answers one task and exits. Because the harness
// loads AGENTS.md / CLAUDE.md from the working directory, whatever context we drop in
// the project folder becomes the harness's briefing — the same instruction files the
// rest of the stack already reads.
function slug(s: string): string {
  return (s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "task");
}

export async function POST(req: Request) {
  const bin = dshBin();
  if (!bin) return new Response(JSON.stringify({ error: "DeepSeek Harness not installed" }), { status: 503 });
  if (!deepseekKey()) return new Response(JSON.stringify({ error: "No DEEPSEEK_API_KEY found" }), { status: 503 });

  const body = await req.json().catch(() => ({}));
  const task: unknown = body.task;
  if (typeof task !== "string" || !task.trim()) {
    return new Response(JSON.stringify({ error: "missing task" }), { status: 400 });
  }
  const name = (typeof body.project === "string" && /^[a-z0-9-]{1,48}$/.test(body.project))
    ? body.project : `${slug(task)}-${Date.now().toString(36).slice(-5)}`;
  const cwd = path.join(DSH_WORKSPACE, name);
  await mkdir(cwd, { recursive: true });

  const child = spawn(bin, ["--profile", "headless", task.slice(0, 8000)], { cwd, env: dshEnv() });

  const stream = new ReadableStream({
    start(controller) {
      const enc = new TextEncoder();
      const send = (o: unknown) => { try { controller.enqueue(enc.encode(JSON.stringify(o) + "\n")); } catch { /* closed */ } };
      send({ type: "start", project: name, cwd });
      child.stdout.on("data", (d: Buffer) => send({ type: "text", text: d.toString() }));
      child.stderr.on("data", (d: Buffer) => send({ type: "info", text: d.toString() }));
      child.on("error", (e) => { send({ type: "error", error: String(e.message || e) }); try { controller.close(); } catch { /* closed */ } });
      child.on("close", (code) => { send({ type: "done", code }); try { controller.close(); } catch { /* closed */ } });
    },
    cancel() { child.kill("SIGTERM"); },
  });

  return new Response(stream, {
    headers: { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-store" },
  });
}
