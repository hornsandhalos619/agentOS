import { NextResponse } from "next/server";
import { pluginsFor } from "@/lib/dsh";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

// GET /api/dsh/plugins — the composed plugin stacks for both profiles.
// `only` = the plugins the web profile has that headless doesn't; on a stock install
// that list is almost entirely the user interface, which is the whole point.
export async function GET() {
  const [web, headless] = await Promise.all([pluginsFor("web"), pluginsFor("headless")]);
  const headlessIds = new Set(headless.map((p) => p.id));
  return NextResponse.json({
    web, headless,
    webOnly: web.filter((p) => !headlessIds.has(p.id)),
    counts: { web: web.length, headless: headless.length },
  });
}
