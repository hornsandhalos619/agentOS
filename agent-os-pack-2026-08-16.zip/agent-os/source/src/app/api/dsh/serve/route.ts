import { spawn } from "node:child_process";
import { mkdir } from "node:fs/promises";
import { NextResponse } from "next/server";
import { deepseekKey, dshBin, dshEnv, DSH_PORT, DSH_URL, DSH_WORKSPACE, webUp } from "@/lib/dsh";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// POST /api/dsh/serve — boot the harness web profile on 3080 and detach it, so it
// keeps serving after this request (and after a dashboard reload) like the other
// long-running engines in the OS.
export async function POST() {
  const bin = dshBin();
  if (!bin) return NextResponse.json({ error: "DeepSeek Harness not installed" }, { status: 503 });
  if (!deepseekKey()) return NextResponse.json({ error: "No DEEPSEEK_API_KEY found — add it to ~/.fcc/.env" }, { status: 503 });
  if (await webUp()) return NextResponse.json({ ok: true, already: true, url: DSH_URL });

  await mkdir(DSH_WORKSPACE, { recursive: true });
  const child = spawn(bin, ["web", "--port", String(DSH_PORT)], {
    cwd: DSH_WORKSPACE, env: dshEnv(), detached: true, stdio: "ignore",
  });
  child.unref();

  // The web profile stacks ~129 plugins on boot, so give it a moment before answering.
  for (let i = 0; i < 40; i++) {
    await new Promise((r) => setTimeout(r, 500));
    if (await webUp()) return NextResponse.json({ ok: true, url: DSH_URL });
  }
  return NextResponse.json({ error: "Harness did not come up in 20s" }, { status: 504 });
}
