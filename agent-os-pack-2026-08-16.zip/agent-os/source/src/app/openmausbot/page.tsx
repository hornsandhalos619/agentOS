import OpenMausBotView from "@/components/OpenMausBotView";

export default function OpenMausBotRoute() {
  return (
    <div className="flex flex-col h-full min-h-0">
      <OpenMausBotView />
    </div>
  );
}
