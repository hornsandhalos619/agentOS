# 🚀 The Agent OS — Start Here

> 🛑 **Don't upload this zip into the Claude / ChatGPT website chat.** Agent OS is a **desktop app you run on your own computer**, not a file for a web chat — uploaded there, Claude won't run it (and won't copy its code). **Unzip it on your computer** and jump to **⚡ Step one** below. *(Want an AI to install it for you? That's `SETUP-GUIDE.md` — you point a terminal agent like Claude Code or Codex at the unzipped folder, never the web chat.)*
>
> 📦 **This pack: version `2026-08-16` (built 16 August 2026).** To check you're on the latest, compare this against the newest pack in the AI Profit Boardroom — or just run `Update Agent OS.command`.
>
> 📅 **See what changed and when → [`CHANGELOG.md`](CHANGELOG.md)** — a day-by-day list of new features and fixes.
>
> 🪟 **On Windows? → [`install/25-WINDOWS-INSTALL.md`](install/25-WINDOWS-INSTALL.md)** is your step-by-step install guide. (The double-click `.command` files are Mac-only — don't use them on Windows. Everything else works the same.)
>
> ✅ **First time installing? Start with the [`IMPLEMENTATION-CHECKLIST.md`](IMPLEMENTATION-CHECKLIST.md)** — a tick-box list to get up and running (only the first four steps are required).
>
> 🔌 **Struggling to link a model, tool or API? → [`SETUP-GUIDE.md`](SETUP-GUIDE.md)** — the "connect everything" guide. Best bit: paste one sentence to Claude/Hermes and it wires up every key for you.
>
> 🗺️ **New here? Follow the [`30-DAY-ROADMAP.md`](30-DAY-ROADMAP.md)** — a simple day-by-day plan from "just installed" to running an AI-first operation. Do one thing a day, skip what you don't need.
>
> ⚖️ **Heads up: this is a power tool you run yourself — use it at your own risk. Please read [`DISCLAIMER.md`](DISCLAIMER.md) first** (no warranty; you're responsible for your keys, costs, and what your agents do).

Welcome. This is your own **AI command center** — one dashboard that runs Claude, Hermes, a voice assistant, an app builder, an AI company, and more, all from one screen.

It looks big. It isn't hard.

---

## ⚡ Step one — start the dashboard (pick your system)

- **🍎 Mac:** double-click **`Start Agent OS.command`**. It checks you have Node (free — sends you to the download if not), installs itself once (a few minutes), then opens your dashboard. *(First double-click: if macOS says "unidentified developer," right-click the file → Open → Open. Once only.)*
- **🪟 Windows:** the `.command` files are **Mac-only** — follow the step-by-step **[`install/25-WINDOWS-INSTALL.md`](install/25-WINDOWS-INSTALL.md)** instead (let an AI do it for you, or 3 PowerShell commands). Everything else works exactly the same.
- **🐧 Linux:** follow the Linux section in **[`install/1-CORE-DASHBOARD.md`](install/1-CORE-DASHBOARD.md)**.

Either way, your dashboard opens at **http://localhost:3737** (use **Chrome**). From the second time on it starts in seconds.

**Wondering what's working and what's not?** Double-click **`Check My Setup.command`** any time — a friendly ✅/⚪️ health check that tells you exactly which guide adds each missing piece.

**Already have an older Agent OS and want the newest features?** Don't re-do the whole install. Download the new pack, then double-click **`Update Agent OS.command`** inside your existing folder — it swaps in the new code and keeps all your settings, keys and notes. Full details in **`UPDATE.md`**.

The dashboard alone is already great. The optional powers (voice, agents, the AI company) each need a small one-time setup — pick a way below.

---

## 🟢 The easiest way to add the rest — let an AI set it up for you (no tech skills needed)

You do **not** need to understand any of this. Let an AI agent do it.

1. **Use any coding agent you already have** — you do **NOT** need a Claude subscription. Any of these work, because they all read the same playbook:
   - **Claude Code** (<https://claude.com/claude-code>) · **Codex** · **Cursor** · **Gemini CLI** · **Hermes** · or **Free Claude Code** (codes for $0 on free models — see `install/5-FREE-CLAUDE-CODE.md`)
2. Open your agent **inside this folder**.
3. Paste this one sentence:

   > **"Read SETUP-WITH-AI.md and set up the whole Agent OS for me, step by step. Ask me whenever you need a key or a decision."**

That's it. The agent reads the playbook, installs everything, and asks you for anything it needs (like a password or a free account). When it's done, it gives you the link to open your dashboard.

> 💡 **No Claude plan? No problem.** Claude Code is just *one* option. On Hermes + OpenRouter? Use Hermes. Prefer Codex/Cursor/Gemini? Use those. Want $0? Use Free Claude Code. They all set it up the same way — there's nothing Claude-only about it.

> 🧠 **This includes connecting your Obsidian vault** (the Memory Galaxy + Jarvis's memory). You never edit any files — just say *"connect my Obsidian vault to the Agent OS"* and the agent finds it and wires it up. Details: `install/11-MEMORY-OBSIDIAN.md`.

---

## 🟡 The guided way — do it yourself with friendly steps

Open the **`install/`** folder. The files are numbered. Do them in order. Each one is written in plain English with copy-paste steps.

> 🧭 **New here? Read `install/0-HOW-IT-ALL-WORKS.md` first (5 min).** It explains how Mission Control, the models, Hermes, Jarvis, and the pipeline fit together — and the one rule that prevents most problems (don't route everything through the tiny free model). Linux users: there's a Linux note in `1-CORE-DASHBOARD.md`.

| # | File | What it sets up | Required? |
|---|------|-----------------|-----------|
| 0 | `0-HOW-IT-ALL-WORKS.md` | How it all fits together + which model does what | 🧭 **Read first** |
| 1 | `1-CORE-DASHBOARD.md` | The dashboard itself (the main screen) | ✅ **Required** |
| 11 | `11-MEMORY-OBSIDIAN.md` | Connect Obsidian → the **Memory Galaxy** + give Jarvis a memory | ⭐ Recommended |
| 2 | `2-VOICE-BUILDING.md` | Say "build me a game" → it builds it, free | ⭐ Recommended |
| 3 | `3-JARVIS-VOICE.md` | The talking voice assistant (Jarvis) | ⭐ Recommended |
| 4 | `4-HERMES.md` | The Hermes agent (does tasks for you) | Optional |
| 5 | `5-FREE-CLAUDE-CODE.md` | Free AI coding (no monthly cost) | Optional |
| 6 | `6-PAPERCLIP.md` | Run a whole company of AI agents | Optional |
| 7 | `7-AGENT-CLIS.md` | Plug in Claude, Codex, Gemini, etc. | Optional |
| 10 | `10-THUMBNAIL-STUDIO.md` | Make better YouTube thumbnails with gpt-image-2 | ⭐ Recommended |
| 12 | `12-VIDEO-STUDIO.md` | Render videos + AI avatar talking-heads | Optional |
| 13 | `13-GAME-STUDIO.md` | Describe a game → play it (free) | Optional |
| 14 | `14-MUSIC-STUDIO.md` | Text prompt → a real song (Suno) | Optional |
| 15 | `15-NOTEBOOKLM.md` | Connect Google NotebookLM (the Notebook tab) | Optional |
| 16 | `16-KIMI-CODE.md` | Add Kimi K2.7 as another coding agent | Optional |
| 17 | `17-EXTRA-MODELS.md` | Chat with GLM 5.2, Fusion + Sakana Fugu (API key) | Optional |
| 18 | `18-GROK-BUILD.md` | xAI's Grok Build coding agent (needs X Premium+) | Optional |
| 19 | `19-LOOP-ENGINEERING.md` | Auto-loop: builder acts, Fusion verifies, repeats till done | 🔧 Advanced |
| 20 | `20-AGENT-KANBAN.md` | A team of local agents works a live board (free, on your Mac) | Optional |
| 21 | `21-OPEN-DESIGN.md` | Local-first design studio (prototypes, decks, images) | 🔧 Advanced |
| 22 | `22-LEADS.md` | Find prospects for outreach (Hunter/Apollo/Firecrawl) | Optional |
| 23 | `23-RADAR.md` | 24/7 AI-news watcher → daily content ideas + hooks | Optional |
| 24 | `24-WINDOWS-STATE-AND-MEMORY.md` | Windows: unify Hermes homes + shared Obsidian memory | 🔧 Advanced |
| 25 | `25-WINDOWS-INSTALL.md` | 🪟 **Windows users start here** — install + run on Windows | ✅ Windows |
| 26 | `26-OPENMONTAGE.md` | Describe a scene → a cinematic video (OpenRouter + ffmpeg) | Optional |
| 27 | `27-GLM-CODE.md` | GPT 5.6 Code tab — one builder, 4 brains (GPT 5.6 / GLM / Kimi K3 / Qwen 3.8) | Optional |
| 28 | `28-OMNIROUTE.md` | Free coding across 90+ providers (auto-fallback) | Optional |
| 29 | `29-OPENSEO.md` | Self-hosted Semrush/Ahrefs (SEO sub-tab, Docker) | Optional |
| 30 | `30-ASTROS.md` | Hermes Astros — 24/7 YouTube watcher (sub-tab) | Optional |
| 31 | `31-HY3-CODER.md` | Cheap fast one-shot builds (Tencent Hy3 via OpenRouter) | Optional |
| 32 | `32-SEO-OFFICE.md` | Local SEO agency OS (SEO sub-tab, clone + pnpm dev) | 🔧 Advanced |
| 33 | `33-VIDEO-EDITOR.md` | Edit any video by chatting (upload → describe → final.mp4) | Optional |
| 34 | `34-OPENCODE.md` | Free terminal coding agent (opencode, built-in free models) | Optional |
| 35 | `35-APP-LAB.md` | Ready-made free AI apps (MoA, web-chat, travel planner) | Optional |
| 36 | `36-SEO-RESEARCH.md` | Connect your own Google Search Console → live keyword research | Optional |
| 37 | `37-DEEPSEEK-CODER.md` | DeepSeek V4 Flash chat + workspace (official API, cheap) | Optional |
| 38 | `38-PARASITE-SEO.md` | One keyword → platform-native content everywhere (SEO sub-tab) | Optional |
| 39 | `39-JCODE.md` | Tiny Rust coding agent on your Claude login (no new key) | Optional |
| 40 | `40-HIGGSFIELD.md` | AI images + video via Hermes (Higgsfield MCP) | Optional |
| 41 | `41-MUSE-CODE.md` | Meta's Muse Spark 1.2 coding model (OpenRouter key) | Optional |
| 42 | `42-PRIME-AGENT.md` | Self-improving Python agent with autonomous mode (Prime Intellect) | Optional |
| 43 | `43-OPENMAUSBOT.md` | A team of AI bots in a chat app, on your existing CLIs | Optional |
| 8 | `8-TROUBLESHOOTING.md` | If anything goes wrong | 🆘 |
| 9 | `9-PHONE-AGENT.md` | Call your agent on a real phone number | 🔧 Advanced |

> 🔄 **Already have an older Agent OS?** Don't fresh-install — read **`UPDATE.md`** to update in place without losing your settings, sessions, or notes.

**You only need #1 to get going.** Everything else you can add later, one at a time. Nothing breaks if you skip a part — that tab just stays quiet.

---

## 🔵 The fast way — if you're technical

```bash
cd source
npm install
PORT=3737 npm run build && PORT=3737 npm start
```

Open <http://localhost:3737>. Then read the install files for the optional services (Ollama, ElevenLabs, Hermes, Paperclip).

---

## What's actually inside

- **The Dashboard** — the screen that ties it all together.
- **Voice Building (Agent Factory)** — talk, and a real app appears. Runs free, on your own computer.
- **Jarvis (the Oracle Control System)** — a voice you talk to. It wakes on its name, answers out loud, shows you things, and builds things.
- **Hermes** — an agent that does multi-step jobs with real tools.
- **Free Claude Code** — code with AI for $0, using free models.
- **Paperclip** — run a team of AI agents like a company, with an org chart.
- **Thumbnail Studio** — upload a thumbnail + say what to improve → gpt-image-2 makes better versions, all logged to your vault.
- **The agent tabs** — Claude, OpenClaw, Gemini, Antigravity, Codex — plug in the ones you use.

### 🗺️ Every tab, at a glance (so nothing's a mystery)

| Sidebar tab | What it does | Setup needed? |
|---|---|---|
| **Mission Control** | Your home overview of everything | None — `1-CORE-DASHBOARD.md` |
| **Memory** | Your notes as a living **galaxy** | Just ask the AI "connect my Obsidian vault" → `11-MEMORY-OBSIDIAN.md` |
| **Notebook** | Google **NotebookLM** — chat with sources, make audio/video/mind-maps | `15-NOTEBOOKLM.md` (install tool + `nlm login`) |
| **Pipeline** | Drop an idea → it gets built | None (uses the free build engine) |
| **Game Studio** | Describe a game → play it | Free engine → `13-GAME-STUDIO.md` |
| **Video** | HyperFrames render + AI avatars | `12-VIDEO-STUDIO.md` (avatars need a key) |
| **Video Editor** | Edit any video by chatting → `final.mp4` | video-use skill + ffmpeg → `33-VIDEO-EDITOR.md` |
| **OpenMontage** | Describe a scene → a cinematic video | OpenRouter + ffmpeg → `26-OPENMONTAGE.md` |
| **Music** | Text prompt → a real song | Suno key → `14-MUSIC-STUDIO.md` |
| **Thumbnails** | Better YouTube thumbnails | OpenAI key → `10-THUMBNAIL-STUDIO.md` |
| **Kanban** | A task board for your work | None |
| **AI Agent Mastermind** | Live group chat — each agent is a *different model* | OpenRouter key (your Hermes key) → `4-HERMES.md` · Free Claude Code agent uses local Ollama |
| **Paperclip** | Run an AI company w/ org chart | `6-PAPERCLIP.md` |
| **Hermes** | The do-things agent + Jarvis voice | `4-HERMES.md` + `3-JARVIS-VOICE.md` |
| **Hermes Cloud** | Run Hermes on the cloud via the Nous portal | Nous account → `4-HERMES.md` |
| **Free Claude Code** | Code with AI for $0 | `5-FREE-CLAUDE-CODE.md` |
| **Local** | Chat with models running on your own Mac (no cloud, no cost) | Ollama → `2-VOICE-BUILDING.md` |
| **GPT 5.6 Code** | One build-me-an-app tab, 4 brains: GPT 5.6 (default), GLM-5.2, Kimi K3, Qwen 3.8 | `27-GLM-CODE.md` |
| **OmniRoute** | Free coding across 90+ providers, auto-fallback | `npm i -g omniroute` → `28-OMNIROUTE.md` |
| **Hy3 Coder** | Cheap fast one-shot builds (Tencent Hy3) | OpenRouter key → `31-HY3-CODER.md` |
| **DeepSeek Coder** | DeepSeek V4 Flash chat + workspace (official API) | DeepSeek key → `37-DEEPSEEK-CODER.md` |
| **jcode** | Featherweight Rust coding agent on your Claude login | Claude login + install → `39-JCODE.md` |
| **Muse Code** | Meta's Muse Spark 1.2 — agent-tuned builds, 1M context | OpenRouter key → `41-MUSE-CODE.md` |
| **Prime Agent** | Python-workspace agent with autonomous mode (budgets + pass/fail gates) | Install + provider → `42-PRIME-AGENT.md` |
| **OpenMausBot** | Your team of named AI bots in a chat app, with OS-wide shared memory | Mac app (.dmg) → `43-OPENMAUSBOT.md` |
| **Higgsfield** | AI images + video, generated through Hermes, auto-galleried | Higgsfield account → `40-HIGGSFIELD.md` |
| **opencode** | Free open-source terminal coding agent (built-in free models) | `curl opencode.ai/install` → `34-OPENCODE.md` |
| **App Lab** | Ready-made free AI apps (MoA, chat-with-webpage, travel planner) | OpenRouter key + clone repo → `35-APP-LAB.md` |
| **Claude · OpenClaw · Gemini · Antigravity · Codex** | Each AI tool's own tab | Install the ones you use → `7-AGENT-CLIS.md` |
| **Kimi Code** | Moonshot's Kimi K2.7 coding agent | `16-KIMI-CODE.md` (install CLI + `kimi login`) |
| **GLM 5.2 · Fusion · Sakana Fugu** | Extra model brains + councils to chat with | API key → `17-EXTRA-MODELS.md` |
| **Grok Build** | xAI's coding agent — build games + apps | X Premium+ → `18-GROK-BUILD.md` |
| **Loop** | Auto-loop: build → verify → repeat till done | OpenRouter → `19-LOOP-ENGINEERING.md` |
| **Agent Kanban** | Local agents work a live board (Planner→Builder→Reviewer) | Free local → `20-AGENT-KANBAN.md` |
| **Open Design** | Local-first design studio (prototypes, decks, images) | Advanced → `21-OPEN-DESIGN.md` |
| **Leads** | Find real prospects + emails for outreach | Optional (free tier) → `22-LEADS.md` |
| **Radar** | 24/7 AI-news watcher → today's content + hooks | Grok login → `23-RADAR.md` |
| **Hermes → Astros** | 24/7 YouTube watcher → video ideas + titles + keywords | Works keyless → `30-ASTROS.md` |
| **SEO** | Generate + publish SEO content | Advanced — needs a coding agent (Claude Code *or* Free Claude Code, `7-AGENT-CLIS.md`) + your own sites |
| **SEO → OpenSEO** | Self-hosted Semrush/Ahrefs (keyword research, ranks, backlinks) | Docker + DataForSEO key → `29-OPENSEO.md` |
| **SEO → SEO Office** | Local SEO agency OS (3D office, claude-seo agents) | Clone + `pnpm dev` → `32-SEO-OFFICE.md` |
| **SEO → Research** | Live keyword research from *your own* Search Console (opportunities, CTR leaks) | Connect your GSC → `36-SEO-RESEARCH.md` |
| **SEO → Parasite SEO** | One winning keyword → platform-native plays for X / IG / TikTok / YouTube | Same GSC connection → `38-PARASITE-SEO.md` |
| **SEO → Transcripts** | Paste/pick a video transcript → turn it into an SEO article | Part of the SEO tab (`7-AGENT-CLIS.md` for the coding agent) |

> A tab that needs a tool you haven't installed just stays quiet — it never breaks anything. Set up only what you'll use.

### ✨ New in this version
- **Hermes → Bots (Bot Mode)** — a roster of named bots, each with its own chat, personality, memory and schedule; same roster as the Hermes desktop app's Bot Mode → `install/4-HERMES.md`.
- **New tab: OpenMausBot** — build a team of named AI bots in an open-source Mac chat app (they run on your existing `claude`/`codex`/`grok` logins), with optional **shared memory**: every bot reads + writes the same Obsidian vault as the rest of your OS → `install/43-OPENMAUSBOT.md`.
- **New tab: Prime Agent** — Prime Intellect's open-source agent with a live Python workspace and **autonomous mode** (turn/token/time budgets + pass/fail gates — it keeps working until the checks go green) → `install/42-PRIME-AGENT.md`.
- **Hermes Muse works on YOUR channel** — the daily YouTube idea forge now reads the channel you set in config (`youtubeChannel` / `furnaceChannels`) instead of anyone else's, and tells you exactly what to set if it's blank → `install/4-HERMES.md`.
- **New tab: Muse Code** — Meta's **Muse Spark 1.2** agent-tuned coding model (1M context) via your OpenRouter key → `install/41-MUSE-CODE.md`.
- **New tab: jcode** — a featherweight open-source Rust coding agent (~28MB RAM) that runs on your **existing Claude login** — no new key, with a session History panel → `install/39-JCODE.md`.
- **New tab: Higgsfield** — generate AI **images + video** through Hermes (Higgsfield's official MCP); every asset auto-saves to an in-tab gallery → `install/40-HIGGSFIELD.md`.
- **New tab: DeepSeek Coder** — chat + build with **DeepSeek V4 Flash** (the 31-July public beta) on DeepSeek's official API; very cheap, very fast reasoning coder → `install/37-DEEPSEEK-CODER.md`.
- **New SEO sub-tab: Parasite SEO** — pick a query you already rank for and get platform-native plays (X thread, IG Reel, TikTok/YouTube Short) with Claude-ready prompts; auto-detects Google's new GSC platform properties the moment the API opens → `install/38-PARASITE-SEO.md`.
- **"Hey Hermes" wake word** — tap the ear in the Hermes tab and talk hands-free; detection is on-device (openwakeword), nothing leaves your Mac → `install/4-HERMES.md`.
- **Free Claude Code router switch** — flip between **OmniRoute** (90+ keyless free providers) and **9Router** (RTK token saver, 20–40% fewer tokens) right in the panel → `install/5-FREE-CLAUDE-CODE.md`.
- **Talk sub-tab removed** from Hermes — real-time voice lives in **Hermes-Jarvis** and the new wake word; one voice path instead of two.
- **Claude Opus 5 is the new default** — the Claude tab + SEO engine now run on **Claude Opus 5** (`claude-opus-5`, launched 24 July 2026), Anthropic's newest flagship. Nothing to set up if your Claude plan has it; prefer Opus 4.8 or Claude 5? One line → `install/7-AGENT-CLIS.md`.
- **New brain: Qwen 3.8** — the **GPT 5.6 Code** tab now offers Alibaba's 2.4T flagship **Qwen 3.8** (via Qoder) alongside GPT 5.6, GLM-5.2 and Kimi K3 — GoldieBench #5, tied with Fable 5. Pick it in the model dropdown → `install/27-GLM-CODE.md`.
- **SEO → Research now works for YOU** — the Research tab pulls live keyword data from *your own* Google Search Console. The connect script now ships (`scripts/gsc-connect.py`) so you authorize your own sites in ~5 min — no more "research script missing", and no one else's domains → `install/36-SEO-RESEARCH.md`.
- **New tab: opencode** — the open-source `opencode` terminal coding agent (160k★) in its own tab, with built-in free models so it builds real apps for $0, no key → `install/34-OPENCODE.md`.
- **New tab: App Lab** — a catalog of ready-to-run AI apps (Mixture-of-Agents, chat-with-any-webpage, travel planner) adapted to free cloud models → `install/35-APP-LAB.md`.
- **New tab: OmniRoute** — free coding across 90+ providers with auto-fallback, no API key → `install/28-OMNIROUTE.md`.
- **New: Implementation Checklist** — a tick-box get-running list for fresh installs → `IMPLEMENTATION-CHECKLIST.md`.
- **New tab: GLM Code** — the real Claude Code agent running on GLM-5.2 (via Ollama Cloud) for much cheaper web-app builds → `install/27-GLM-CODE.md`.
- **New tab: OpenMontage** — describe a scene → a short cinematic video (Cinematic mode is cheap + fast; Movie mode is premium). Uses your OpenRouter key + ffmpeg → `install/26-OPENMONTAGE.md`.
- **Hermes Mixture-of-Agents (MoA)** — run several models together and blend their answers for tougher questions.
- **Windows install guide + 30-Day Roadmap** — `install/25-WINDOWS-INSTALL.md` (Windows users start here) and `30-DAY-ROADMAP.md` (a day-by-day plan), both linked from the top.
- **Windows: one unified Hermes home** — Agent OS now reads `HERMES_HOME` (the same var the Hermes CLI uses), so one setting unifies it with native Windows Hermes instead of splitting state across `~/.hermes` and `%LOCALAPPDATA%\hermes`. Default is unchanged. New guide: `install/24-WINDOWS-STATE-AND-MEMORY.md` (also covers one shared Obsidian memory across all your tools).
- **New tab: Leads** — find real prospects + their emails for outreach (Hunter/Apollo/Firecrawl, free tier to start) → `install/22-LEADS.md`.
- **New tab: Radar** — a 24/7 AI-news watcher that hands you today's biggest story + a ready-to-post hook → `install/23-RADAR.md`.
- **Update on Windows / with any agent** — `UPDATE-WITH-AI.md`: a safe cross-platform updater for Codex/Claude/Cursor.
- **Any agent can set it up** — no Claude subscription needed (Codex, Cursor, Gemini, Hermes, or Free Claude Code all work).
- **Hermes / OpenClaw / Antigravity chat now remember the conversation**; the **Claude tab** uses `claude login` (no empty API key); the **SEO Pack download** is fixed; and the **Mastermind** agents are repointable in `config.json`.
- **Disclaimer added** — a plain-English "use at your own risk" notice (`DISCLAIMER.md`), linked up top and shown on launch.
- **New tab: Sakana Fugu** — a vendor-agnostic model council (panel + judge, cheaper per call than Fusion) → `install/17-EXTRA-MODELS.md`.
- **Gemini → Antigravity** — Google retired the Gemini CLI (18 Jun 2026); the Gemini tab now points you to **Antigravity**, its successor → `install/7-AGENT-CLIS.md`.
- **Clearer updates** — `UPDATE.md` now explains exactly what an update keeps (your settings/keys/vault) vs replaces (the app code) — put settings in `config.json` so they survive.
- **Every install is now truly yours** — fixed a bug where a fresh setup acted like the creator's (called you "Julian", referenced his projects/company/voice). Now it's clean + personal; set your name with `"userName"` in `config.json`.
- **Change the Jarvis voice** — connect your ElevenLabs key and pick any voice (ask your AI, the Director dropdown, or `AGENTIC_OS_TTS_VOICE`) → `install/3-JARVIS-VOICE.md`.
- **New tab: Agent Kanban** — a team of local agents (Planner → Builder → Reviewer) works a live board for free, 100% on your machine → `install/20-AGENT-KANBAN.md`.
- **New tab: Open Design** (advanced) — a local-first design studio embedded in the dashboard (prototypes, decks, images, motion) → `install/21-OPEN-DESIGN.md`.
- **"How it all works" overview** — a 5-minute read that explains Mission Control, every model, Hermes/Jarvis, the pipeline, and the one rule that prevents most problems → `install/0-HOW-IT-ALL-WORKS.md`. Plus a **Linux** section in `1-CORE-DASHBOARD.md`.
- **New tab: Loop** — define what "done" means and it auto-loops (a builder acts, Fusion verifies adversarially) until the gate passes → `install/19-LOOP-ENGINEERING.md`.
- **New tab: Grok Build** — xAI's `grok-build` coding agent in its own tab (build games + apps, they land in your Workspace). Runs on your **X Premium+** plan → `install/18-GROK-BUILD.md`.
- **Hermes profiles explained** — the Hermes → Chat tab shows a hint when you have no profiles yet, and the guide explains they're *yours* + how to create them (`hermes profile create`) → `install/4-HERMES.md`.
- **Jarvis briefings** — ask Jarvis (in the Hermes tab) for a **daily or weekly briefing** and it reads your Obsidian vault to give you your to-dos, wins, and what you worked on, with a spoken summary → `install/4-HERMES.md`.
- **Claude chat remembers the conversation** — the basic Claude tab now keeps full context across messages (it used to forget between turns). New **New chat** button starts fresh.
- **Much easier Obsidian setup** — just tell your AI *"connect my Obsidian vault"* — no files to edit. The guide leads with the simple way → `install/11-MEMORY-OBSIDIAN.md`.
- **Two new model tabs: GLM 5.2 & Fusion** — chat with Zhipu's GLM-5.2 and OpenRouter's Fusion (a blend of top models), each with one key, no install → `install/17-EXTRA-MODELS.md`.
- **Daily changelog** — a day-by-day list of every new feature and fix → see `CHANGELOG.md`.
- **Kimi Code** — a new agent tab: Moonshot's **Kimi K2.7** coding agent, alongside Claude/Codex/etc. Install the CLI + `kimi login` → see `install/16-KIMI-CODE.md`.
- **NotebookLM connects properly for everyone** — fixed a bug where the Notebook tab pointed at one person's folder (`spawn …ENOENT`); it now finds NotebookLM on *your* Mac automatically. Full setup in `install/15-NOTEBOOKLM.md`.
- **Music Studio + Video Studio** — generate songs (Suno) and videos (HyperFrames + AI avatars), each with its own guide.
- **One-click updater** — double-click `Update Agent OS.command` to move to the newest version, keeping all your settings.
- **Claude model choice** — the Claude tab runs on **Claude Opus 5** (`claude-opus-5`) by default, Anthropic's newest flagship. Prefer Opus 4.8 or Claude 5? Change one line — see the ⭐ section in `install/7-AGENT-CLIS.md`.
- **Thumbnail Studio** — the new gpt-image-2 thumbnail maker (sidebar → Thumbnails). See `install/10-THUMBNAIL-STUDIO.md`.
- **Jarvis upgrades** — now runs on your connected MiniMax plan (not pay-per-token), reads your whole Obsidian vault to answer "what do you remember…" and "what happened yesterday", and runs silent (no blips).
- **Build gallery** — every app you've built with the Agent Factory shows as live previews inside the Hermes-Jarvis tab.
- **Pipeline** — idea → agents plan + build it → it self-checks the result before showing you, with a Gallery of recent builds.
- **Agent Mastermind** — group chat with all your agents now saves to your vault and shows on any device (plus it no longer crashes on imported conversations).
- **Full Hermes guide** — `install/4-HERMES.md` now walks every one of Hermes' ten sections (Jarvis, Studio, Workspace, Goal Mode and all), so nothing in that tab is a mystery.

---

## 🔒 Security, in plain English

Built private by default — nothing extra for you to do:

- **Everything runs on YOUR computer.** Your notes, your builds, your conversations — none of it goes to us or anyone else.
- **The dashboard only answers your own machine.** It's locked to `localhost`, so nobody on your Wi-Fi (café, hotel, office) can open it — only you.
- **Your keys live in files on your Mac**, locked to your user account (the start script quietly checks this every launch). This pack ships with **placeholders only** — never real keys.
- **You enter your own keys and payments, always.** No guide here will ever ask you to give an AI your password or card — if an AI offers to log in for you, say no.
- **Pausing is safe.** Stop the dashboard any time (close the window). Nothing breaks, nothing is lost.

## The one rule

Take it **one piece at a time**. Double-click Start, get the dashboard working, enjoy it. Then add a piece whenever you want a new power. You can't break it by going slow.

Need help? `8-TROUBLESHOOTING.md` covers the common snags — or just paste the error into Claude and ask "how do I fix this?"
